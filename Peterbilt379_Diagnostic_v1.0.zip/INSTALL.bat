@echo off
echo ============================================
echo  ROTS Trucking - Peterbilt 379 Diagnostic
echo  Version 1.0 - READ-ONLY MODE
echo ============================================
echo.
echo Finding Python...

REM Try python in PATH first
where python >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=python
    goto :found
)

REM Try py launcher
where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py
    goto :found
)

REM Try python3
where python3 >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=python3
    goto :found
)

REM Search common install locations
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
    "C:\Python39\python.exe"
    "%APPDATA%\Python\Python312\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python311\python.exe"
    "%ProgramFiles(x86)%\Python312\python.exe"
) do (
    if exist %%P (
        set PYTHON_CMD=%%P
        goto :found
    )
)

echo.
echo ERROR: Python not found!
echo.
echo Please install Python from:
echo   https://www.python.org/downloads/
echo.
echo IMPORTANT: Check "Add Python to PATH" during install!
echo Then close this window and run INSTALL.bat again.
echo.
pause
exit /b 1

:found
echo Found Python: %PYTHON_CMD%
%PYTHON_CMD% --version
echo.
echo Installing packages...
%PYTHON_CMD% -m pip install --upgrade pip
%PYTHON_CMD% -m pip install -r requirements.txt
echo.
echo ============================================
echo  Installation complete!
echo  To run: double-click RUN.bat
echo ============================================
echo.

REM Save python path for RUN.bat
echo %PYTHON_CMD%> .python_path
echo Python path saved for RUN.bat
echo.
pause
