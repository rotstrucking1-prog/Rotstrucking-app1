================================================================
  ROTS Trucking — Peterbilt 379 Diagnostic Suite
  Version 1.0 — READ-ONLY MODE
================================================================

Vehicle: 1996 Peterbilt 379
Engine:  Cummins N14 Celect Plus
VIN:     1XP5D68X3TD371440

================================================================
  SAFETY NOTICE
================================================================

This version is READ-ONLY. It can ONLY read data from your ECM.
It CANNOT write parameters, clear codes, or modify anything.
Your ECM is 100% safe.

The J1708 bus is a shared data bus — reading from it is the same
thing your dashboard gauges do. No risk of damage.

================================================================
  SETUP INSTRUCTIONS
================================================================

1. Install Python (if not already installed):
   - Download from: https://www.python.org/downloads/
   - IMPORTANT: Check "Add Python to PATH" during installation

2. Install required packages:
   - Double-click INSTALL.bat
   - Or run: pip install PyQt5 pyserial

3. Hardware connection:
   - Plug Vgate vLinker FS USB adapter into laptop
   - Connect 6-pin Deutsch cable from adapter to truck diagnostic port
   - Turn truck key to ON position (engine can be off or running)

4. Run the program:
   - Double-click RUN.bat
   - Or run: python main.py

================================================================
  USING THE PROGRAM
================================================================

CONNECT TAB:
  - Click "Scan Ports" to find your USB adapter
  - Click "AUTO-DETECT" to connect automatically
  - Or select the port and click "CONNECT"

DASHBOARD TAB:
  - Shows all live engine gauges
  - Green = normal, Yellow = warning, Red = critical
  - Switch views: All Gauges, Engine Core, Temperatures, etc.
  - 240°F coolant = RED ZONE — STOP ENGINE

CHECK CODES TAB:
  - Click "READ CODES" to scan for diagnostic trouble codes
  - Active codes = current problems (check engine light)
  - Stored codes = past problems that may have cleared

DATA LOG TAB:
  - Click "START LOGGING" to record all data to CSV files
  - Files saved in the "logs" folder
  - Great for tracking engine health over time
  - Open CSV files in Excel or Google Sheets

================================================================
  WHAT IT READS
================================================================

12 Live Gauges:
  1. Engine RPM
  2. Boost Pressure (PSI)
  3. Oil Pressure (PSI)
  4. Coolant Temperature (°F)
  5. Oil Temperature (°F)
  6. Fuel Rail Pressure (PSI)
  7. Battery Voltage (V)
  8. Exhaust Gas Temperature (°F)
  9. Vehicle Speed (MPH)
  10. Throttle Position (%)
  11. Engine Load (%)
  12. Instant MPG

Plus: Fuel Temp, Intake Temp, Alternator Current, Fuel Rate,
     Trans Temp, Turbo Speed, Coolant Level, Coolant Pressure,
     Ambient Temp, Engine Hours, Total Fuel Used

50+ Diagnostic Trouble Codes (DTCs) recognized

================================================================
  TROUBLESHOOTING
================================================================

"No ports found":
  - Make sure USB adapter is plugged in
  - Try a different USB port
  - Check Windows Device Manager for the COM port
  - Install adapter drivers if needed

"Not receiving data":
  - Make sure truck key is ON
  - Check 6-pin Deutsch connector is seated firmly
  - Try both ELM327 and GENERIC adapter modes

"Python not found":
  - Install Python from python.org
  - Make sure "Add to PATH" was checked during install
  - Restart your command prompt after installing

================================================================
  TRANSFERRING TO ANOTHER COMPUTER
================================================================

Just copy this entire folder to the other computer.
Then run INSTALL.bat and RUN.bat. That's it.

================================================================
  ROTS TRUCKING LLC — Bradley Alan Haga
================================================================
