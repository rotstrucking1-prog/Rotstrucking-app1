@echo off
echo Starting Peterbilt 379 Diagnostic Suite...
echo.

REM Check if saved python path exists
if exist .python_path (
    set /p PYTHON_CMD=<.python_path
    goto :run
)

REM Try finding python
where python >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=python
    goto :run
)

where py >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=py
    goto :run
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    set PYTHON_CMD=python3
    goto :run
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "%ProgramFiles%\Python312\python.exe"
) do (
    if exist %%P (
        set PYTHON_CMD=%%P
        goto :run
    )
)

echo ERROR: Python not found! Run INSTALL.bat first.
pause
exit /b 1

:run
echo Using: %PYTHON_CMD%
%PYTHON_CMD% main.py
pause
