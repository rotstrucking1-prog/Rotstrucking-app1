"""
J1708/J1587 Communication Layer
Handles serial communication with the Cummins N14 ECM via USB OBD-II adapter.

Protocol: SAE J1708 (physical layer) + J1587 (data layer)
Baud: 9600
Connector: 6-pin Deutsch → OBD-II Y-Connector → USB adapter

Supported adapters:
  - ELM327 USB (with J1708 mode)
  - Vgate vLinker FS OBD2 USB
  - Any J1708-compatible serial adapter
"""

import serial
import serial.tools.list_ports
import threading
import time
import struct
from collections import deque
from data.n14_params import (
    PIDS, DTC_CODES, TUNABLE_PARAMS,
    J1708_MID_ENGINE, J1708_BAUD, J1708_MAX_MSG_LEN,
    j1708_checksum
)


class J1708Connection:
    """Manages the serial connection to the J1708 bus via USB adapter."""

    def __init__(self):
        self.port = None
        self.serial_conn = None
        self.connected = False
        self.adapter_type = None  # "ELM327", "VGATE", "GENERIC"
        self.rx_buffer = deque(maxlen=5000)
        self.tx_lock = threading.Lock()
        self.rx_thread = None
        self.running = False

        # Live data storage
        self.live_data = {}
        self.active_dtcs = []
        self.inactive_dtcs = []
        self.data_callbacks = []
        self.dtc_callbacks = []
        self.connection_callbacks = []

        # Statistics
        self.messages_received = 0
        self.messages_sent = 0
        self.errors = 0
        self.last_message_time = 0

    # ---- Port Discovery ----

    def scan_ports(self):
        """Scan for available COM ports and identify compatible adapters."""
        ports = []
        for port in serial.tools.list_ports.comports():
            info = {
                "port": port.device,
                "description": port.description,
                "hwid": port.hwid,
                "vid": port.vid,
                "pid": port.pid,
                "manufacturer": port.manufacturer,
                "is_compatible": False,
                "adapter_type": "UNKNOWN"
            }

            desc_lower = (port.description or "").lower()
            mfg_lower = (port.manufacturer or "").lower()

            # Identify adapter type
            if "elm327" in desc_lower or "elm" in desc_lower:
                info["is_compatible"] = True
                info["adapter_type"] = "ELM327"
            elif "vgate" in desc_lower or "vlinker" in desc_lower:
                info["is_compatible"] = True
                info["adapter_type"] = "VGATE"
            elif "ftdi" in mfg_lower or "ch340" in desc_lower or "cp210" in desc_lower:
                info["is_compatible"] = True
                info["adapter_type"] = "GENERIC"
            elif "usb" in desc_lower and "serial" in desc_lower:
                info["is_compatible"] = True
                info["adapter_type"] = "GENERIC"

            ports.append(info)
        return ports

    def auto_detect_port(self):
        """Auto-detect the best available adapter port."""
        ports = self.scan_ports()
        # Priority: ELM327 > VGATE > GENERIC
        for adapter_type in ["ELM327", "VGATE", "GENERIC"]:
            for p in ports:
                if p["adapter_type"] == adapter_type and p["is_compatible"]:
                    return p
        return None

    # ---- Connection Management ----

    def connect(self, port=None, auto=True):
        """
        Connect to the J1708 bus.
        Args:
            port: COM port string (e.g., "COM3"). If None, auto-detect.
            auto: If True, auto-detect the adapter.
        Returns:
            dict with status, message, and adapter info.
        """
        if self.connected:
            self.disconnect()

        # Find port
        if port is None and auto:
            detected = self.auto_detect_port()
            if detected is None:
                return {
                    "status": "error",
                    "message": "No compatible adapter found. Check USB connection.",
                    "ports_found": [p["port"] for p in self.scan_ports()]
                }
            port = detected["port"]
            self.adapter_type = detected["adapter_type"]
        elif port:
            self.adapter_type = "GENERIC"
        else:
            return {"status": "error", "message": "No port specified and auto-detect disabled."}

        try:
            self.serial_conn = serial.Serial(
                port=port,
                baudrate=J1708_BAUD,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=1.0,
                write_timeout=1.0
            )

            # Initialize adapter
            init_result = self._init_adapter()
            if not init_result["success"]:
                self.serial_conn.close()
                return {"status": "error", "message": init_result["message"]}

            self.port = port
            self.connected = True
            self.running = True
            self.messages_received = 0
            self.messages_sent = 0
            self.errors = 0

            # Start receiver thread
            self.rx_thread = threading.Thread(target=self._receive_loop, daemon=True)
            self.rx_thread.start()

            self._notify_connection(True)

            return {
                "status": "connected",
                "message": "Connected to {} on {}".format(self.adapter_type, port),
                "port": port,
                "adapter": self.adapter_type
            }

        except serial.SerialException as e:
            return {"status": "error", "message": "Serial error: {}".format(str(e))}
        except Exception as e:
            return {"status": "error", "message": "Connection failed: {}".format(str(e))}

    def disconnect(self):
        """Disconnect from the J1708 bus."""
        self.running = False
        self.connected = False

        if self.rx_thread and self.rx_thread.is_alive():
            self.rx_thread.join(timeout=3)

        if self.serial_conn and self.serial_conn.is_open:
            try:
                self.serial_conn.close()
            except Exception:
                pass

        self.serial_conn = None
        self.port = None
        self._notify_connection(False)
        return {"status": "disconnected", "message": "Disconnected from adapter."}

    def _init_adapter(self):
        """Initialize the adapter based on type."""
        try:
            if self.adapter_type == "ELM327":
                return self._init_elm327()
            elif self.adapter_type == "VGATE":
                return self._init_vgate()
            else:
                return self._init_generic()
        except Exception as e:
            return {"success": False, "message": "Adapter init failed: {}".format(str(e))}

    def _init_elm327(self):
        """Initialize ELM327 adapter for J1708 mode."""
        commands = [
            (b"ATZ\r", 2.0),    # Reset
            (b"ATE0\r", 0.5),   # Echo off
            (b"ATL0\r", 0.5),   # Linefeeds off
            (b"ATS0\r", 0.5),   # Spaces off
            (b"ATSP5\r", 0.5),  # Protocol 5 = SAE J1708
        ]
        for cmd, delay in commands:
            self.serial_conn.write(cmd)
            time.sleep(delay)
            resp = self.serial_conn.read(self.serial_conn.in_waiting or 64)
            if b"ERROR" in resp:
                # Try J1850 VPW as fallback (similar timing)
                if cmd == b"ATSP5\r":
                    self.serial_conn.write(b"ATSP2\r")
                    time.sleep(0.5)
                    resp = self.serial_conn.read(self.serial_conn.in_waiting or 64)
                    if b"ERROR" in resp:
                        return {"success": False, "message": "ELM327 doesn't support J1708 protocol"}
        return {"success": True, "message": "ELM327 initialized for J1708"}

    def _init_vgate(self):
        """Initialize Vgate vLinker adapter."""
        # Vgate uses similar AT commands
        commands = [
            (b"ATZ\r", 2.0),
            (b"ATE0\r", 0.5),
            (b"ATSP5\r", 0.5),
        ]
        for cmd, delay in commands:
            self.serial_conn.write(cmd)
            time.sleep(delay)
            self.serial_conn.read(self.serial_conn.in_waiting or 64)
        return {"success": True, "message": "Vgate initialized for J1708"}

    def _init_generic(self):
        """Initialize generic serial adapter — direct J1708 passthrough."""
        # Generic adapters typically pass raw J1708 data
        self.serial_conn.reset_input_buffer()
        self.serial_conn.reset_output_buffer()
        return {"success": True, "message": "Generic adapter initialized (raw J1708 mode)"}

    # ---- Data Reception ----

    def _receive_loop(self):
        """Background thread: continuously read J1708 messages from the bus."""
        buffer = bytearray()

        while self.running and self.serial_conn and self.serial_conn.is_open:
            try:
                if self.serial_conn.in_waiting > 0:
                    data = self.serial_conn.read(self.serial_conn.in_waiting)
                    buffer.extend(data)

                    # Process complete messages from buffer
                    while len(buffer) >= 3:  # Minimum: MID + PID + checksum
                        msg = self._extract_message(buffer)
                        if msg is None:
                            break
                        if msg == "skip":
                            buffer.pop(0)
                            continue

                        msg_len = msg["length"]
                        buffer = buffer[msg_len:]
                        self._process_message(msg)
                else:
                    time.sleep(0.01)

            except serial.SerialException:
                self.errors += 1
                if not self.running:
                    break
                time.sleep(0.5)
            except Exception:
                self.errors += 1
                time.sleep(0.05)

    def _extract_message(self, buffer):
        """Extract a single J1708 message from the buffer."""
        if len(buffer) < 3:
            return None

        mid = buffer[0]

        # Validate MID range (128-255 for standard J1708)
        if mid < 128:
            return "skip"

        # Determine message length based on PID
        # J1587 PIDs 0-127 = 1 data byte, 128-191 = 2 bytes, 192-253 = variable, 254-255 = extension
        if len(buffer) < 3:
            return None

        pid = buffer[1]

        if pid <= 127:
            data_bytes = 1
        elif pid <= 191:
            data_bytes = 2
        elif pid <= 253:
            if len(buffer) < 4:
                return None
            data_bytes = buffer[2]
            if data_bytes > 18:
                return "skip"
        elif pid == 254:
            if len(buffer) < 4:
                return None
            data_bytes = 2  # Extension PID uses next 2 bytes
        elif pid == 255:
            if len(buffer) < 5:
                return None
            data_bytes = buffer[3]

        # Total message length = MID + PID + data + checksum
        msg_len = 2 + data_bytes + 1
        if pid >= 192 and pid <= 253:
            msg_len += 1  # Extra byte for length field

        if len(buffer) < msg_len:
            return None

        msg_data = bytes(buffer[:msg_len])

        # Verify checksum
        expected_ck = j1708_checksum(msg_data[:-1])
        if msg_data[-1] != expected_ck:
            self.errors += 1
            return "skip"

        # Extract data portion
        if pid <= 191:
            value_bytes = msg_data[2:2 + data_bytes]
        elif pid <= 253:
            value_bytes = msg_data[3:3 + data_bytes]
        else:
            value_bytes = msg_data[2:2 + data_bytes]

        return {
            "mid": mid,
            "pid": pid,
            "data": value_bytes,
            "raw": msg_data,
            "length": msg_len,
            "timestamp": time.time()
        }

    def _process_message(self, msg):
        """Process a received J1708 message and update live data."""
        self.messages_received += 1
        self.last_message_time = msg["timestamp"]

        mid = msg["mid"]
        pid = msg["pid"]
        data = msg["data"]

        # Check if this is from the engine ECM
        if mid == J1708_MID_ENGINE:
            self._process_engine_data(pid, data, msg["timestamp"])

        # Check for DTC messages (PID 194 = active, PID 195 = inactive)
        if pid == 194:
            self._process_dtc(mid, data, active=True)
        elif pid == 195:
            self._process_dtc(mid, data, active=False)

        # Store raw message
        self.rx_buffer.append(msg)

    def _process_engine_data(self, pid, data, timestamp):
        """Decode engine PID data and update live_data dictionary."""
        for key, param in PIDS.items():
            if param["pid"] == pid:
                value = self._decode_pid_value(pid, data, param)
                if value is not None:
                    old_value = self.live_data.get(key, {}).get("value")
                    self.live_data[key] = {
                        "value": value,
                        "unit": param["unit"],
                        "timestamp": timestamp,
                        "name": param["name"],
                        "status": self._get_status(key, value)
                    }
                    # Notify callbacks
                    for cb in self.data_callbacks:
                        try:
                            cb(key, value, old_value, timestamp)
                        except Exception:
                            pass
                break

        # Calculate derived values
        self._calculate_derived(timestamp)

    def _decode_pid_value(self, pid, data, param):
        """Decode raw bytes to a parameter value based on PID definition."""
        try:
            num_bytes = param["bytes"]
            resolution = param["resolution"]

            if num_bytes == 1 and len(data) >= 1:
                raw = data[0]
            elif num_bytes == 2 and len(data) >= 2:
                raw = struct.unpack(">H", data[:2])[0]
            elif num_bytes == 4 and len(data) >= 4:
                raw = struct.unpack(">I", data[:4])[0]
            else:
                return None

            # Apply resolution and offset
            value = raw * resolution

            # Temperature PIDs use offset of -40 (standard J1587)
            if param["unit"] == "F" and pid in [110, 175, 174, 105, 173, 177, 171]:
                value = (raw * resolution) - 40
                # Convert C to F if needed
                if value < -40:
                    value = (value * 9.0 / 5.0) + 32

            # Clamp to valid range
            value = max(param["min"], min(param["max"], value))
            return round(value, 2)

        except Exception:
            return None

    def _calculate_derived(self, timestamp):
        """Calculate derived values like instant MPG."""
        speed = self.live_data.get("VEHICLE_SPEED", {}).get("value")
        fuel_rate = self.live_data.get("FUEL_RATE", {}).get("value")

        if speed is not None and fuel_rate is not None and fuel_rate > 0.1:
            # MPG = speed (mph) / fuel_rate (gal/hr)
            mpg = speed / fuel_rate
            mpg = min(20.0, max(0, mpg))
            self.live_data["INSTANT_MPG"] = {
                "value": round(mpg, 2),
                "unit": "MPG",
                "timestamp": timestamp,
                "name": "Instant MPG",
                "status": self._get_status("INSTANT_MPG", mpg)
            }

    def _get_status(self, key, value):
        """Determine status (NORMAL, WARNING, CRITICAL) for a parameter."""
        param = PIDS.get(key)
        if param is None:
            return "NORMAL"

        critical = param.get("critical")
        warning = param.get("warning")

        if critical is None and warning is None:
            return "NORMAL"

        # For parameters where LOW is dangerous (oil pressure, fuel pressure, coolant level)
        low_danger = key in ["OIL_PRESS", "FUEL_PRESS", "BATTERY_VOLTS", "ALT_CURRENT",
                             "COOLANT_LEVEL", "COOLANT_PRESS", "INSTANT_MPG"]

        if low_danger:
            if critical is not None and value <= critical:
                return "CRITICAL"
            if warning is not None and value <= warning:
                return "WARNING"
        else:
            if critical is not None and value >= critical:
                return "CRITICAL"
            if warning is not None and value >= warning:
                return "WARNING"

        return "NORMAL"

    def _process_dtc(self, mid, data, active=True):
        """Process a Diagnostic Trouble Code message."""
        if len(data) < 2:
            return

        # J1587 DTC format: SID/PID + FMI
        code_num = data[0]
        fmi = data[1] if len(data) > 1 else 0

        dtc_info = DTC_CODES.get(code_num, {
            "desc": "Unknown Code {}".format(code_num),
            "severity": "UNKNOWN",
            "action": "Refer to service manual"
        })

        dtc = {
            "code": code_num,
            "fmi": fmi,
            "mid": mid,
            "description": dtc_info["desc"],
            "severity": dtc_info["severity"],
            "action": dtc_info["action"],
            "active": active,
            "timestamp": time.time()
        }

        target_list = self.active_dtcs if active else self.inactive_dtcs

        # Update or add
        existing = None
        for i, d in enumerate(target_list):
            if d["code"] == code_num and d["mid"] == mid:
                existing = i
                break

        if existing is not None:
            target_list[existing] = dtc
        else:
            target_list.append(dtc)

        # Notify
        for cb in self.dtc_callbacks:
            try:
                cb(dtc)
            except Exception:
                pass

    # ---- Data Transmission (ECM Write) ----

    def send_message(self, mid, pid, data):
        """
        Send a J1708 message on the bus.
        Args:
            mid: Module ID (source)
            pid: Parameter ID
            data: bytes of data to send
        Returns:
            dict with status.
        """
        if not self.connected:
            return {"status": "error", "message": "Not connected"}

        with self.tx_lock:
            try:
                msg = bytearray()
                msg.append(mid)
                msg.append(pid)
                msg.extend(data)
                msg.append(j1708_checksum(msg))

                if len(msg) > J1708_MAX_MSG_LEN:
                    return {"status": "error", "message": "Message too long ({} > {})".format(len(msg), J1708_MAX_MSG_LEN)}

                self.serial_conn.write(bytes(msg))
                self.serial_conn.flush()
                self.messages_sent += 1

                return {"status": "sent", "length": len(msg)}

            except Exception as e:
                self.errors += 1
                return {"status": "error", "message": str(e)}

    def request_pid(self, pid):
        """Request a specific PID from the engine ECM."""
        # J1708 request: send to MID 128 (engine), PID 0 = request, data = target PID
        return self.send_message(0xAC, 0, bytes([J1708_MID_ENGINE, pid]))

    def request_all_pids(self):
        """Request all defined PIDs from the engine ECM."""
        results = []
        for key, param in PIDS.items():
            if param["pid"] is not None:
                result = self.request_pid(param["pid"])
                results.append({"pid_name": key, "result": result})
                time.sleep(0.05)  # Small delay between requests
        return results

    def read_dtcs(self):
        """Request all active and inactive DTCs from the ECM."""
        # Request active DTCs (PID 194)
        self.send_message(0xAC, 0, bytes([J1708_MID_ENGINE, 194]))
        time.sleep(0.2)
        # Request inactive DTCs (PID 195)
        self.send_message(0xAC, 0, bytes([J1708_MID_ENGINE, 195]))
        time.sleep(0.2)
        return {"active": list(self.active_dtcs), "inactive": list(self.inactive_dtcs)}

    def clear_dtcs(self):
        """Clear all diagnostic trouble codes from ECM. Use with caution."""
        # J1587 DTC clear: MID 172, PID 196, data = target MID
        return self.send_message(172, 196, bytes([J1708_MID_ENGINE]))

    # ---- ECM Parameter Write (TUNING) ----

    def read_ecm_parameter(self, param_key):
        """Read a tunable ECM parameter value."""
        if param_key not in TUNABLE_PARAMS:
            return {"status": "error", "message": "Unknown parameter: {}".format(param_key)}

        # Use Cummins-specific PID for parameter read
        # PID 255 = extension message for proprietary data
        param_id = list(TUNABLE_PARAMS.keys()).index(param_key)
        self.send_message(0xAC, 255, bytes([0x01, param_id]))  # 0x01 = read request
        time.sleep(0.3)

        return {"status": "requested", "param": param_key}

    def write_ecm_parameter(self, param_key, value):
        """
        Write a tunable parameter to the ECM.
        SAFETY: Validates value against min/max before writing.
        Returns backup of previous value for revert capability.
        """
        if param_key not in TUNABLE_PARAMS:
            return {"status": "error", "message": "Unknown parameter: {}".format(param_key)}

        param = TUNABLE_PARAMS[param_key]

        # SAFETY CHECK — Enforce min/max
        if value < param["min_safe"]:
            return {
                "status": "error",
                "message": "Value {} below minimum safe limit ({} {})".format(
                    value, param["min_safe"], param["unit"]
                )
            }
        if value > param["max_safe"]:
            return {
                "status": "error",
                "message": "Value {} exceeds maximum safe limit ({} {})".format(
                    value, param["max_safe"], param["unit"]
                )
            }

        # Read current value first (for backup/revert)
        # In production, this would read from ECM — for now store in memory
        param_id = list(TUNABLE_PARAMS.keys()).index(param_key)

        # Encode value
        if isinstance(value, float):
            data = struct.pack(">f", value)
        else:
            data = struct.pack(">H", int(value))

        # Write command: PID 255 (extension), 0x02 = write, param_id, value
        write_data = bytearray([0x02, param_id])
        write_data.extend(data)

        result = self.send_message(0xAC, 255, bytes(write_data))

        if result["status"] == "sent":
            return {
                "status": "written",
                "param": param_key,
                "value": value,
                "unit": param["unit"],
                "message": "{} set to {} {}".format(param["name"], value, param["unit"])
            }
        return result

    # ---- Callback Registration ----

    def on_data_update(self, callback):
        """Register callback for live data updates: callback(key, value, old_value, timestamp)"""
        self.data_callbacks.append(callback)

    def on_dtc(self, callback):
        """Register callback for DTC events: callback(dtc_dict)"""
        self.dtc_callbacks.append(callback)

    def on_connection_change(self, callback):
        """Register callback for connection state changes: callback(connected: bool)"""
        self.connection_callbacks.append(callback)

    def _notify_connection(self, connected):
        for cb in self.connection_callbacks:
            try:
                cb(connected)
            except Exception:
                pass

    # ---- Status ----

    def get_status(self):
        """Get current connection status and statistics."""
        return {
            "connected": self.connected,
            "port": self.port,
            "adapter": self.adapter_type,
            "messages_received": self.messages_received,
            "messages_sent": self.messages_sent,
            "errors": self.errors,
            "live_params": len(self.live_data),
            "active_dtcs": len(self.active_dtcs),
            "inactive_dtcs": len(self.inactive_dtcs),
            "last_message": self.last_message_time,
        }
