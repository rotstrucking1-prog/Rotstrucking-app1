"""
CSV Data Logger
Logs all diagnostic data, tune changes, DTCs, and fuel economy to CSV files.
"""

import csv
import os
import time
import threading


class DataLogger:
    """Logs diagnostic data to CSV files."""

    def __init__(self, log_dir=None):
        if log_dir is None:
            log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)

        self.logging_active = False
        self.log_interval = 1.0  # seconds between log entries
        self.session_id = time.strftime("%Y%m%d_%H%M%S")
        self._lock = threading.Lock()

        # File handles
        self._data_file = None
        self._data_writer = None
        self._dtc_file = None
        self._dtc_writer = None
        self._tune_file = None
        self._tune_writer = None
        self._fuel_file = None
        self._fuel_writer = None

    def start_logging(self, session_label=""):
        """Start a new logging session."""
        if self.logging_active:
            self.stop_logging()

        self.session_id = time.strftime("%Y%m%d_%H%M%S")
        label = "_" + session_label if session_label else ""
        prefix = "session_{}{}".format(self.session_id, label)

        # Data log — all PID readings
        data_path = os.path.join(self.log_dir, "{}_data.csv".format(prefix))
        self._data_file = open(data_path, "w", newline="")
        self._data_writer = csv.writer(self._data_file)
        self._data_writer.writerow([
            "Timestamp", "DateTime", "RPM", "Boost_PSI", "Oil_Press_PSI",
            "Coolant_Temp_F", "Oil_Temp_F", "Fuel_Temp_F", "Fuel_Press_PSI",
            "Battery_V", "Intake_Temp_F", "EGT_F", "Vehicle_Speed_MPH",
            "Throttle_Pct", "Alt_Current_A", "Engine_Load_Pct", "Fuel_Rate_GPH",
            "Instant_MPG", "Trans_Temp_F", "Turbo_RPM", "Coolant_Level_Pct",
            "Coolant_Press_PSI", "Ambient_Temp_F", "Engine_Hours"
        ])

        # DTC log
        dtc_path = os.path.join(self.log_dir, "{}_dtcs.csv".format(prefix))
        self._dtc_file = open(dtc_path, "w", newline="")
        self._dtc_writer = csv.writer(self._dtc_file)
        self._dtc_writer.writerow([
            "Timestamp", "DateTime", "Code", "FMI", "Description",
            "Severity", "Action", "Active"
        ])

        # Tune change log
        tune_path = os.path.join(self.log_dir, "{}_tune_changes.csv".format(prefix))
        self._tune_file = open(tune_path, "w", newline="")
        self._tune_writer = csv.writer(self._tune_file)
        self._tune_writer.writerow([
            "Timestamp", "DateTime", "Action", "Profile_ID", "Profile_Name",
            "Parameter", "Old_Value", "New_Value", "Unit"
        ])

        # Fuel economy log
        fuel_path = os.path.join(self.log_dir, "{}_fuel.csv".format(prefix))
        self._fuel_file = open(fuel_path, "w", newline="")
        self._fuel_writer = csv.writer(self._fuel_file)
        self._fuel_writer.writerow([
            "Timestamp", "DateTime", "Speed_MPH", "RPM", "Fuel_Rate_GPH",
            "Instant_MPG", "Avg_MPG", "Total_Fuel_Gal", "Total_Miles",
            "Throttle_Pct", "Engine_Load_Pct", "Best_RPM_Zone"
        ])

        self.logging_active = True
        return {
            "status": "started",
            "session": self.session_id,
            "data_file": data_path,
            "dtc_file": dtc_path,
            "tune_file": tune_path,
            "fuel_file": fuel_path,
        }

    def stop_logging(self):
        """Stop the current logging session."""
        self.logging_active = False
        for fh in [self._data_file, self._dtc_file, self._tune_file, self._fuel_file]:
            if fh:
                try:
                    fh.flush()
                    fh.close()
                except Exception:
                    pass
        self._data_file = self._dtc_file = self._tune_file = self._fuel_file = None
        self._data_writer = self._dtc_writer = self._tune_writer = self._fuel_writer = None
        return {"status": "stopped", "session": self.session_id}

    def log_data_snapshot(self, live_data):
        """Log a snapshot of all current PID values."""
        if not self.logging_active or not self._data_writer:
            return

        now = time.time()
        dt = time.strftime("%Y-%m-%d %H:%M:%S")

        def val(key):
            d = live_data.get(key, {})
            return d.get("value", "")

        with self._lock:
            try:
                self._data_writer.writerow([
                    round(now, 3), dt,
                    val("RPM"), val("BOOST"), val("OIL_PRESS"),
                    val("COOLANT_TEMP"), val("OIL_TEMP"), val("FUEL_TEMP"), val("FUEL_PRESS"),
                    val("BATTERY_VOLTS"), val("INTAKE_TEMP"), val("EXHAUST_TEMP"),
                    val("VEHICLE_SPEED"), val("THROTTLE_POS"), val("ALT_CURRENT"),
                    val("ENGINE_LOAD"), val("FUEL_RATE"), val("INSTANT_MPG"),
                    val("TRANS_TEMP"), val("TURBO_SPEED"), val("COOLANT_LEVEL"),
                    val("COOLANT_PRESS"), val("AMBIENT_TEMP"), val("ENGINE_HOURS")
                ])
                self._data_file.flush()
            except Exception:
                pass

    def log_dtc(self, dtc):
        """Log a DTC event."""
        if not self.logging_active or not self._dtc_writer:
            return
        with self._lock:
            try:
                self._dtc_writer.writerow([
                    round(time.time(), 3), time.strftime("%Y-%m-%d %H:%M:%S"),
                    dtc.get("code"), dtc.get("fmi"), dtc.get("description"),
                    dtc.get("severity"), dtc.get("action"), dtc.get("active")
                ])
                self._dtc_file.flush()
            except Exception:
                pass

    def log_tune_change(self, action, profile_id, profile_name, param="", old_val="", new_val="", unit=""):
        """Log a tune profile change."""
        if not self.logging_active or not self._tune_writer:
            return
        with self._lock:
            try:
                self._tune_writer.writerow([
                    round(time.time(), 3), time.strftime("%Y-%m-%d %H:%M:%S"),
                    action, profile_id, profile_name, param, old_val, new_val, unit
                ])
                self._tune_file.flush()
            except Exception:
                pass

    def log_fuel_snapshot(self, live_data, avg_mpg, total_fuel, total_miles, best_rpm_zone=""):
        """Log fuel economy data point."""
        if not self.logging_active or not self._fuel_writer:
            return

        def val(key):
            return live_data.get(key, {}).get("value", "")

        with self._lock:
            try:
                self._fuel_writer.writerow([
                    round(time.time(), 3), time.strftime("%Y-%m-%d %H:%M:%S"),
                    val("VEHICLE_SPEED"), val("RPM"), val("FUEL_RATE"),
                    val("INSTANT_MPG"), round(avg_mpg, 2) if avg_mpg else "",
                    round(total_fuel, 2) if total_fuel else "",
                    round(total_miles, 2) if total_miles else "",
                    val("THROTTLE_POS"), val("ENGINE_LOAD"), best_rpm_zone
                ])
                self._fuel_file.flush()
            except Exception:
                pass

    def list_sessions(self):
        """List all logged sessions."""
        sessions = {}
        for f in os.listdir(self.log_dir):
            if f.startswith("session_") and f.endswith(".csv"):
                parts = f.split("_")
                if len(parts) >= 3:
                    sid = parts[1] + "_" + parts[2].split("_")[0] if len(parts) > 2 else parts[1]
                    if sid not in sessions:
                        sessions[sid] = {"files": [], "session_id": sid}
                    sessions[sid]["files"].append(os.path.join(self.log_dir, f))
        return list(sessions.values())
