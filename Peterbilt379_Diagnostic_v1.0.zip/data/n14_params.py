"""
Cummins N14 ECM Parameter Definitions
1996 Peterbilt 379 — N14 Celect/Celect Plus

All J1708 PIDs, ranges, and tuning parameters for the N14 engine.
References: SAE J1708/J1587, Cummins INSITE documentation, N14 service manuals.
"""

# ============================================================
# J1708/J1587 Parameter IDs (PIDs) for reading ECM data
# ============================================================

# Standard engine PIDs (J1587)
PIDS = {
    # --- Core Engine Data ---
    "RPM": {
        "pid": 190,
        "name": "Engine RPM",
        "unit": "RPM",
        "min": 0,
        "max": 2500,
        "normal_min": 600,
        "normal_max": 2100,
        "warning": 2200,
        "critical": 2400,
        "resolution": 0.25,
        "bytes": 2,
        "description": "Engine crankshaft speed"
    },
    "BOOST": {
        "pid": 102,
        "name": "Boost Pressure",
        "unit": "PSI",
        "min": 0,
        "max": 60,
        "normal_min": 0,
        "normal_max": 45,
        "warning": 50,
        "critical": 55,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Turbocharger boost pressure"
    },
    "OIL_PRESS": {
        "pid": 100,
        "name": "Oil Pressure",
        "unit": "PSI",
        "min": 0,
        "max": 120,
        "normal_min": 30,
        "normal_max": 80,
        "warning": 20,
        "critical": 10,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Engine oil pressure"
    },
    "COOLANT_TEMP": {
        "pid": 110,
        "name": "Coolant Temperature",
        "unit": "F",
        "min": -40,
        "max": 300,
        "normal_min": 180,
        "normal_max": 210,
        "warning": 225,
        "critical": 240,
        "resolution": 1,
        "bytes": 1,
        "description": "Engine coolant temperature"
    },
    "OIL_TEMP": {
        "pid": 175,
        "name": "Oil Temperature",
        "unit": "F",
        "min": -40,
        "max": 350,
        "normal_min": 180,
        "normal_max": 240,
        "warning": 260,
        "critical": 280,
        "resolution": 1,
        "bytes": 1,
        "description": "Engine oil temperature"
    },
    "FUEL_TEMP": {
        "pid": 174,
        "name": "Fuel Temperature",
        "unit": "F",
        "min": -40,
        "max": 250,
        "normal_min": 80,
        "normal_max": 150,
        "warning": 170,
        "critical": 200,
        "resolution": 1,
        "bytes": 1,
        "description": "Fuel temperature at ECM"
    },
    "FUEL_PRESS": {
        "pid": 94,
        "name": "Fuel Pressure",
        "unit": "PSI",
        "min": 0,
        "max": 200,
        "normal_min": 25,
        "normal_max": 150,
        "warning": 20,
        "critical": 10,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Fuel rail pressure"
    },
    "BATTERY_VOLTS": {
        "pid": 168,
        "name": "Battery Voltage",
        "unit": "V",
        "min": 0,
        "max": 32,
        "normal_min": 12.0,
        "normal_max": 14.8,
        "warning": 11.5,
        "critical": 10.5,
        "resolution": 0.05,
        "bytes": 2,
        "description": "System battery voltage"
    },
    "INTAKE_TEMP": {
        "pid": 105,
        "name": "Intake Manifold Temp",
        "unit": "F",
        "min": -40,
        "max": 300,
        "normal_min": 50,
        "normal_max": 180,
        "warning": 200,
        "critical": 230,
        "resolution": 1,
        "bytes": 1,
        "description": "Intake manifold air temperature"
    },
    "EXHAUST_TEMP": {
        "pid": 173,
        "name": "Exhaust Gas Temp",
        "unit": "F",
        "min": 0,
        "max": 1600,
        "normal_min": 400,
        "normal_max": 1000,
        "warning": 1200,
        "critical": 1400,
        "resolution": 1,
        "bytes": 2,
        "description": "Exhaust gas temperature (pyrometer)"
    },
    "VEHICLE_SPEED": {
        "pid": 84,
        "name": "Vehicle Speed",
        "unit": "MPH",
        "min": 0,
        "max": 130,
        "normal_min": 0,
        "normal_max": 75,
        "warning": 80,
        "critical": 85,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Vehicle road speed"
    },
    "THROTTLE_POS": {
        "pid": 91,
        "name": "Throttle Position",
        "unit": "%",
        "min": 0,
        "max": 100,
        "normal_min": 0,
        "normal_max": 100,
        "warning": None,
        "critical": None,
        "resolution": 0.4,
        "bytes": 1,
        "description": "Accelerator pedal position"
    },

    # --- Electrical System ---
    "ALT_CURRENT": {
        "pid": 114,
        "name": "Alternator Output",
        "unit": "A",
        "min": 0,
        "max": 200,
        "normal_min": 13,
        "normal_max": 150,
        "warning": 10,
        "critical": 5,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Alternator charging current"
    },
    "ENGINE_LOAD": {
        "pid": 92,
        "name": "Engine Load",
        "unit": "%",
        "min": 0,
        "max": 125,
        "normal_min": 0,
        "normal_max": 100,
        "warning": 105,
        "critical": 120,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Percent engine load at current speed"
    },
    "ENGINE_HOURS": {
        "pid": 247,
        "name": "Engine Hours",
        "unit": "hrs",
        "min": 0,
        "max": 999999,
        "normal_min": 0,
        "normal_max": 999999,
        "warning": None,
        "critical": None,
        "resolution": 0.05,
        "bytes": 4,
        "description": "Total engine operating hours"
    },
    "TOTAL_FUEL": {
        "pid": 250,
        "name": "Total Fuel Used",
        "unit": "gal",
        "min": 0,
        "max": 9999999,
        "normal_min": 0,
        "normal_max": 9999999,
        "warning": None,
        "critical": None,
        "resolution": 0.125,
        "bytes": 4,
        "description": "Lifetime total fuel consumption"
    },
    "FUEL_RATE": {
        "pid": 183,
        "name": "Fuel Rate",
        "unit": "GPH",
        "min": 0,
        "max": 50,
        "normal_min": 2,
        "normal_max": 20,
        "warning": 25,
        "critical": 35,
        "resolution": 0.05,
        "bytes": 2,
        "description": "Current fuel consumption rate"
    },
    "INSTANT_MPG": {
        "pid": None,  # Calculated from speed / fuel_rate
        "name": "Instant MPG",
        "unit": "MPG",
        "min": 0,
        "max": 20,
        "normal_min": 4.0,
        "normal_max": 8.0,
        "warning": 3.0,
        "critical": 2.0,
        "resolution": 0.01,
        "bytes": 0,
        "description": "Calculated: Vehicle Speed / Fuel Rate"
    },
    "TRANS_TEMP": {
        "pid": 177,
        "name": "Transmission Temp",
        "unit": "F",
        "min": -40,
        "max": 350,
        "normal_min": 150,
        "normal_max": 220,
        "warning": 240,
        "critical": 260,
        "resolution": 1,
        "bytes": 1,
        "description": "Transmission oil temperature"
    },
    "TURBO_SPEED": {
        "pid": 103,
        "name": "Turbo Speed",
        "unit": "RPM",
        "min": 0,
        "max": 200000,
        "normal_min": 0,
        "normal_max": 130000,
        "warning": 150000,
        "critical": 170000,
        "resolution": 4,
        "bytes": 2,
        "description": "Turbocharger shaft speed"
    },
    "COOLANT_LEVEL": {
        "pid": 111,
        "name": "Coolant Level",
        "unit": "%",
        "min": 0,
        "max": 100,
        "normal_min": 70,
        "normal_max": 100,
        "warning": 50,
        "critical": 30,
        "resolution": 0.5,
        "bytes": 1,
        "description": "Engine coolant level"
    },
    "COOLANT_PRESS": {
        "pid": 109,
        "name": "Coolant Pressure",
        "unit": "PSI",
        "min": 0,
        "max": 30,
        "normal_min": 5,
        "normal_max": 18,
        "warning": 3,
        "critical": 1,
        "resolution": 0.25,
        "bytes": 1,
        "description": "Coolant system pressure"
    },
    "AMBIENT_TEMP": {
        "pid": 171,
        "name": "Ambient Air Temp",
        "unit": "F",
        "min": -40,
        "max": 150,
        "normal_min": 0,
        "normal_max": 120,
        "warning": None,
        "critical": None,
        "resolution": 1,
        "bytes": 1,
        "description": "Outside air temperature"
    },
}

# ============================================================
# Diagnostic Trouble Codes (DTCs) — N14 Common Codes
# ============================================================

DTC_CODES = {
    111: {"desc": "ECM Hardware Fault", "severity": "CRITICAL", "action": "Replace ECM"},
    115: {"desc": "Vehicle Speed Sensor", "severity": "WARNING", "action": "Check VSS wiring/sensor"},
    122: {"desc": "Boost Pressure Sensor High", "severity": "WARNING", "action": "Check boost sensor"},
    123: {"desc": "Boost Pressure Sensor Low", "severity": "WARNING", "action": "Check boost sensor/wiring"},
    131: {"desc": "Accelerator Position Sensor", "severity": "WARNING", "action": "Check TPS wiring"},
    132: {"desc": "Accelerator Position Sensor High", "severity": "WARNING", "action": "Check TPS"},
    135: {"desc": "Oil Pressure Sensor", "severity": "WARNING", "action": "Check oil pressure sensor"},
    141: {"desc": "Oil Pressure Low", "severity": "CRITICAL", "action": "STOP ENGINE - Check oil level/pump"},
    143: {"desc": "Oil Pressure Very Low", "severity": "CRITICAL", "action": "STOP ENGINE IMMEDIATELY"},
    144: {"desc": "Coolant Temperature Sensor", "severity": "WARNING", "action": "Check coolant temp sensor"},
    145: {"desc": "Coolant Temperature High", "severity": "CRITICAL", "action": "STOP - Check cooling system"},
    146: {"desc": "Coolant Temperature Very High", "severity": "CRITICAL", "action": "STOP ENGINE IMMEDIATELY"},
    151: {"desc": "Coolant Level Low", "severity": "WARNING", "action": "Check coolant level/sensor"},
    153: {"desc": "Intake Manifold Temp High", "severity": "WARNING", "action": "Check intercooler/air system"},
    154: {"desc": "Intake Manifold Temp Sensor", "severity": "WARNING", "action": "Check IAT sensor"},
    155: {"desc": "Intake Manifold Pressure Sensor", "severity": "WARNING", "action": "Check MAP sensor"},
    187: {"desc": "Sensor Supply Voltage High", "severity": "WARNING", "action": "Check ECM power supply"},
    227: {"desc": "Sensor Supply Voltage Low", "severity": "WARNING", "action": "Check ECM wiring"},
    234: {"desc": "Engine Overspeed", "severity": "CRITICAL", "action": "Check throttle system"},
    235: {"desc": "Coolant Level Sensor", "severity": "WARNING", "action": "Check coolant level sensor"},
    241: {"desc": "Vehicle Speed Sensor Lost Signal", "severity": "WARNING", "action": "Check VSS"},
    242: {"desc": "Vehicle Speed Sensor Erratic", "severity": "WARNING", "action": "Check VSS wiring"},
    245: {"desc": "Fan Clutch Driver Fault", "severity": "WARNING", "action": "Check fan clutch wiring"},
    254: {"desc": "ECM Hardware Fault (secondary)", "severity": "CRITICAL", "action": "Replace ECM"},
    255: {"desc": "Battery Voltage High", "severity": "WARNING", "action": "Check alternator/regulator"},
    256: {"desc": "Battery Voltage Low", "severity": "WARNING", "action": "Check batteries/charging"},
    261: {"desc": "Fuel Temp Sensor", "severity": "WARNING", "action": "Check fuel temp sensor"},
    263: {"desc": "Fuel Temp High", "severity": "WARNING", "action": "Check fuel cooling"},
    271: {"desc": "Timing Actuator Fault", "severity": "WARNING", "action": "Check timing actuator"},
    272: {"desc": "Timing Actuator Calibration", "severity": "WARNING", "action": "Recalibrate timing"},
    285: {"desc": "AC Pressure Sensor", "severity": "INFO", "action": "Check AC system sensor"},
    286: {"desc": "AC High Pressure", "severity": "WARNING", "action": "Check AC compressor/system"},
    311: {"desc": "EGR System Fault", "severity": "WARNING", "action": "Check EGR valve/system"},
    319: {"desc": "Idle Shutdown Timer Active", "severity": "INFO", "action": "Normal - idle timer running"},
    322: {"desc": "Injector Metering Rail Pressure High", "severity": "CRITICAL", "action": "Check fuel system"},
    323: {"desc": "Injector Metering Rail Pressure Low", "severity": "CRITICAL", "action": "Check fuel filter/pump"},
    334: {"desc": "Engine Retarder Fault", "severity": "WARNING", "action": "Check Jake brake system"},
    343: {"desc": "ECM/CPU Internal Fault", "severity": "CRITICAL", "action": "Power cycle / replace ECM"},
    352: {"desc": "Sensor Supply Voltage 2", "severity": "WARNING", "action": "Check secondary supply"},
    386: {"desc": "Sensor Supply Voltage 3", "severity": "WARNING", "action": "Check tertiary supply"},
    415: {"desc": "Oil Pressure Very Low (derate)", "severity": "CRITICAL", "action": "STOP ENGINE - low oil"},
    422: {"desc": "Coolant Level Very Low", "severity": "CRITICAL", "action": "STOP - add coolant"},
    431: {"desc": "Idle Validation Switch", "severity": "WARNING", "action": "Check idle switch"},
    432: {"desc": "Clutch Switch", "severity": "INFO", "action": "Check clutch switch"},
    433: {"desc": "Brake Switch Fault", "severity": "WARNING", "action": "Check brake switch"},
    441: {"desc": "Battery Voltage Very Low", "severity": "CRITICAL", "action": "Check batteries NOW"},
    442: {"desc": "Battery Voltage Very High", "severity": "CRITICAL", "action": "Check alternator - overcharging"},
    449: {"desc": "Fuel Shutoff Valve", "severity": "CRITICAL", "action": "Check fuel solenoid"},
    451: {"desc": "Injector Circuit Cylinder 1", "severity": "CRITICAL", "action": "Check injector 1 wiring"},
    452: {"desc": "Injector Circuit Cylinder 2", "severity": "CRITICAL", "action": "Check injector 2 wiring"},
    453: {"desc": "Injector Circuit Cylinder 3", "severity": "CRITICAL", "action": "Check injector 3 wiring"},
    454: {"desc": "Injector Circuit Cylinder 4", "severity": "CRITICAL", "action": "Check injector 4 wiring"},
    455: {"desc": "Injector Circuit Cylinder 5", "severity": "CRITICAL", "action": "Check injector 5 wiring"},
    456: {"desc": "Injector Circuit Cylinder 6", "severity": "CRITICAL", "action": "Check injector 6 wiring"},
}

# ============================================================
# TUNABLE N14 PARAMETERS — ECM Write Capability
# ============================================================

TUNABLE_PARAMS = {
    "RATED_HP": {
        "name": "Rated Horsepower",
        "unit": "HP",
        "factory_default": 460,
        "min_safe": 330,
        "max_safe": 600,
        "step": 5,
        "description": "Peak engine horsepower rating. N14 factory options: 330, 370, 410, 435, 460, 500, 525, 600.",
        "risk": "MEDIUM",
        "notes": "Higher HP increases fuel consumption and component stress. Stay within engine build spec."
    },
    "PEAK_TORQUE": {
        "name": "Peak Torque",
        "unit": "lb-ft",
        "factory_default": 1650,
        "min_safe": 1250,
        "max_safe": 2000,
        "step": 25,
        "description": "Maximum engine torque output. N14 factory range: 1250-1850 lb-ft.",
        "risk": "MEDIUM",
        "notes": "Excessive torque can damage drivetrain components. Match to transmission rating."
    },
    "GOVERNOR_SPEED": {
        "name": "High Idle / Governor Speed",
        "unit": "RPM",
        "factory_default": 2100,
        "min_safe": 1800,
        "max_safe": 2300,
        "step": 25,
        "description": "Maximum governed RPM. Controls top speed and power curve.",
        "risk": "LOW",
        "notes": "Higher RPM = more available power but reduced fuel economy."
    },
    "LOW_IDLE": {
        "name": "Low Idle Speed",
        "unit": "RPM",
        "factory_default": 650,
        "min_safe": 550,
        "max_safe": 800,
        "step": 25,
        "description": "Engine idle RPM. Lower = better fuel economy at idle.",
        "risk": "LOW",
        "notes": "Too low may cause rough idle or stalling under electrical load."
    },
    "INJECTION_TIMING": {
        "name": "Injection Timing Advance",
        "unit": "degrees BTDC",
        "factory_default": 12.0,
        "min_safe": 8.0,
        "max_safe": 20.0,
        "step": 0.5,
        "description": "Fuel injection timing advance before top dead center.",
        "risk": "HIGH",
        "notes": "Advanced timing = more power & efficiency but higher combustion temps. Risk of piston/head damage if excessive."
    },
    "FUEL_RATE_LIMIT": {
        "name": "Fuel Rate Limit",
        "unit": "mm3/stroke",
        "factory_default": 220,
        "min_safe": 150,
        "max_safe": 300,
        "step": 5,
        "description": "Maximum fuel volume per injection event. Primary power control.",
        "risk": "HIGH",
        "notes": "Too much fuel = black smoke, excessive EGT, turbo damage. Always monitor EGT."
    },
    "TORQUE_RISE": {
        "name": "Torque Rise Profile",
        "unit": "%",
        "factory_default": 40,
        "min_safe": 25,
        "max_safe": 60,
        "step": 5,
        "description": "Percent torque increase from rated speed to peak torque RPM. Higher = more lugging ability.",
        "risk": "MEDIUM",
        "notes": "Higher torque rise helps maintain speed on hills without downshifting."
    },
    "ROAD_SPEED_LIMIT": {
        "name": "Road Speed Limit",
        "unit": "MPH",
        "factory_default": 70,
        "min_safe": 55,
        "max_safe": 85,
        "step": 1,
        "description": "Maximum governed vehicle speed.",
        "risk": "LOW",
        "notes": "Ensure tires and drivetrain are rated for selected speed."
    },
    "CRUISE_MAX_SPEED": {
        "name": "Cruise Control Max Speed",
        "unit": "MPH",
        "factory_default": 68,
        "min_safe": 50,
        "max_safe": 80,
        "step": 1,
        "description": "Maximum speed selectable via cruise control.",
        "risk": "LOW",
        "notes": "Should be at or below road speed limit."
    },
    "ENGINE_BRAKE_LEVEL": {
        "name": "Engine Brake (Jake) Level",
        "unit": "level",
        "factory_default": 3,
        "min_safe": 1,
        "max_safe": 3,
        "step": 1,
        "description": "Jake brake aggressiveness: 1=Low, 2=Medium, 3=Full. Controls number of active cylinders.",
        "risk": "LOW",
        "notes": "Higher level = more braking force. Wet roads: use level 1-2 only."
    },
}

# ============================================================
# Pre-built Tune Profiles (Tunes 1-10)
# ============================================================

DEFAULT_TUNE_PROFILES = {
    1: {
        "name": "Stock / Factory",
        "description": "Original factory settings — safest option",
        "active": True,
        "color": "#4CAF50",
        "params": {
            "RATED_HP": 460,
            "PEAK_TORQUE": 1650,
            "GOVERNOR_SPEED": 2100,
            "LOW_IDLE": 650,
            "INJECTION_TIMING": 12.0,
            "FUEL_RATE_LIMIT": 220,
            "TORQUE_RISE": 40,
            "ROAD_SPEED_LIMIT": 70,
            "CRUISE_MAX_SPEED": 68,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    2: {
        "name": "Economy",
        "description": "Maximum fuel efficiency — lower power, best MPG",
        "active": False,
        "color": "#2196F3",
        "params": {
            "RATED_HP": 370,
            "PEAK_TORQUE": 1350,
            "GOVERNOR_SPEED": 1900,
            "LOW_IDLE": 600,
            "INJECTION_TIMING": 11.0,
            "FUEL_RATE_LIMIT": 180,
            "TORQUE_RISE": 35,
            "ROAD_SPEED_LIMIT": 65,
            "CRUISE_MAX_SPEED": 63,
            "ENGINE_BRAKE_LEVEL": 2,
        }
    },
    3: {
        "name": "Power",
        "description": "Increased horsepower for heavy loads — higher fuel usage",
        "active": False,
        "color": "#FF9800",
        "params": {
            "RATED_HP": 525,
            "PEAK_TORQUE": 1850,
            "GOVERNOR_SPEED": 2200,
            "LOW_IDLE": 650,
            "INJECTION_TIMING": 14.0,
            "FUEL_RATE_LIMIT": 260,
            "TORQUE_RISE": 50,
            "ROAD_SPEED_LIMIT": 72,
            "CRUISE_MAX_SPEED": 70,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    4: {
        "name": "Max Performance",
        "description": "Maximum safe power output — monitor EGT closely!",
        "active": False,
        "color": "#F44336",
        "params": {
            "RATED_HP": 600,
            "PEAK_TORQUE": 2000,
            "GOVERNOR_SPEED": 2300,
            "LOW_IDLE": 700,
            "INJECTION_TIMING": 16.0,
            "FUEL_RATE_LIMIT": 290,
            "TORQUE_RISE": 55,
            "ROAD_SPEED_LIMIT": 78,
            "CRUISE_MAX_SPEED": 75,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    5: {
        "name": "Mountain / Hill Climber",
        "description": "High torque rise for grades — maintains speed on hills",
        "active": False,
        "color": "#795548",
        "params": {
            "RATED_HP": 500,
            "PEAK_TORQUE": 1950,
            "GOVERNOR_SPEED": 2100,
            "LOW_IDLE": 650,
            "INJECTION_TIMING": 13.5,
            "FUEL_RATE_LIMIT": 250,
            "TORQUE_RISE": 60,
            "ROAD_SPEED_LIMIT": 68,
            "CRUISE_MAX_SPEED": 65,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    6: {
        "name": "City / Stop & Go",
        "description": "Low-speed torque optimized for city driving and docks",
        "active": False,
        "color": "#9C27B0",
        "params": {
            "RATED_HP": 410,
            "PEAK_TORQUE": 1550,
            "GOVERNOR_SPEED": 2000,
            "LOW_IDLE": 600,
            "INJECTION_TIMING": 11.5,
            "FUEL_RATE_LIMIT": 200,
            "TORQUE_RISE": 45,
            "ROAD_SPEED_LIMIT": 60,
            "CRUISE_MAX_SPEED": 55,
            "ENGINE_BRAKE_LEVEL": 2,
        }
    },
    7: {
        "name": "Highway Cruise",
        "description": "Optimized for flat highway — steady cruise, good MPG",
        "active": False,
        "color": "#00BCD4",
        "params": {
            "RATED_HP": 435,
            "PEAK_TORQUE": 1550,
            "GOVERNOR_SPEED": 2050,
            "LOW_IDLE": 625,
            "INJECTION_TIMING": 12.5,
            "FUEL_RATE_LIMIT": 210,
            "TORQUE_RISE": 38,
            "ROAD_SPEED_LIMIT": 72,
            "CRUISE_MAX_SPEED": 70,
            "ENGINE_BRAKE_LEVEL": 2,
        }
    },
    8: {
        "name": "Cold Weather",
        "description": "Higher idle for cold starts — faster warm-up",
        "active": False,
        "color": "#607D8B",
        "params": {
            "RATED_HP": 460,
            "PEAK_TORQUE": 1650,
            "GOVERNOR_SPEED": 2100,
            "LOW_IDLE": 800,
            "INJECTION_TIMING": 13.0,
            "FUEL_RATE_LIMIT": 220,
            "TORQUE_RISE": 40,
            "ROAD_SPEED_LIMIT": 70,
            "CRUISE_MAX_SPEED": 68,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    9: {
        "name": "Custom 1",
        "description": "User-defined custom tune profile",
        "active": False,
        "color": "#E91E63",
        "params": {
            "RATED_HP": 460,
            "PEAK_TORQUE": 1650,
            "GOVERNOR_SPEED": 2100,
            "LOW_IDLE": 650,
            "INJECTION_TIMING": 12.0,
            "FUEL_RATE_LIMIT": 220,
            "TORQUE_RISE": 40,
            "ROAD_SPEED_LIMIT": 70,
            "CRUISE_MAX_SPEED": 68,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
    10: {
        "name": "Custom 2",
        "description": "User-defined custom tune profile",
        "active": False,
        "color": "#FF5722",
        "params": {
            "RATED_HP": 460,
            "PEAK_TORQUE": 1650,
            "GOVERNOR_SPEED": 2100,
            "LOW_IDLE": 650,
            "INJECTION_TIMING": 12.0,
            "FUEL_RATE_LIMIT": 220,
            "TORQUE_RISE": 40,
            "ROAD_SPEED_LIMIT": 70,
            "CRUISE_MAX_SPEED": 68,
            "ENGINE_BRAKE_LEVEL": 3,
        }
    },
}

# ============================================================
# Electrical System Components — Full Diagnostics
# ============================================================

ELECTRICAL_SYSTEMS = {
    "STARTING": {
        "name": "Starting System",
        "components": [
            "Batteries (2x 12V in parallel)",
            "Starter Motor",
            "Starter Solenoid",
            "Ignition Switch",
            "Neutral Safety Switch",
            "Battery Cables (pos/neg)",
            "Battery Disconnect Switch",
        ]
    },
    "CHARGING": {
        "name": "Charging System",
        "components": [
            "Alternator (130A+)",
            "Voltage Regulator",
            "Battery Isolator",
            "Charge Wiring",
        ]
    },
    "LIGHTING": {
        "name": "Lighting System",
        "components": [
            "Headlights (low/high beam)",
            "Marker Lights",
            "Clearance Lights",
            "Turn Signals",
            "Brake Lights",
            "Tail Lights",
            "Reverse Lights",
            "ICC Lights (cab/sleeper)",
            "Interior/Dome Lights",
            "Dash Lights",
        ]
    },
    "GAUGES": {
        "name": "Gauge Cluster",
        "components": [
            "Speedometer",
            "Tachometer",
            "Oil Pressure",
            "Coolant Temperature",
            "Fuel Level",
            "Voltmeter",
            "Pyrometer (aftermarket)",
            "Boost Gauge (aftermarket)",
            "Trans Temp (aftermarket)",
        ]
    },
    "ENGINE_CONTROLS": {
        "name": "Engine Control System",
        "components": [
            "ECM (Celect/Celect Plus)",
            "Injector Solenoids (6x)",
            "Timing Actuator",
            "Fuel Shutoff Solenoid",
            "Engine Position Sensor",
            "Camshaft Sensor",
            "Coolant Temp Sensor",
            "Oil Pressure Sensor",
            "Boost Pressure Sensor",
            "Intake Temp Sensor",
            "Fuel Temp Sensor",
            "Throttle Position Sensor",
            "Vehicle Speed Sensor",
            "Fan Clutch Solenoid",
        ]
    },
    "ACCESSORIES": {
        "name": "Accessory Systems",
        "components": [
            "AC Compressor Clutch",
            "Heater/Defroster Blower",
            "Wiper Motors",
            "Horn(s)",
            "Air Dryer Heater",
            "Block Heater",
            "CB Radio",
            "ELD/Omnitracs",
        ]
    },
    "SAFETY": {
        "name": "Safety Systems",
        "components": [
            "ABS Module",
            "ABS Wheel Speed Sensors (6x)",
            "ABS Modulator Valves",
            "Air Pressure Sensors",
            "Low Air Warning Buzzer",
            "Backup Alarm",
        ]
    },
}

# ============================================================
# J1708 Protocol Constants
# ============================================================

J1708_MID_ENGINE = 128       # Engine ECM (Cummins N14)
J1708_MID_TRANS = 130        # Transmission
J1708_MID_ABS = 136          # ABS Module
J1708_MID_INSTRUMENT = 140   # Instrument Cluster
J1708_MID_CLIMATE = 146      # HVAC/Climate
J1708_MID_RETARDER = 137     # Engine Retarder (Jake)

J1708_BAUD = 9600            # J1708 always 9600 baud
J1708_MAX_MSG_LEN = 21       # Max message length in bytes

# Checksum calculation
def j1708_checksum(data):
    """Calculate J1708 message checksum (two's complement of sum mod 256)"""
    return (256 - (sum(data) % 256)) % 256
