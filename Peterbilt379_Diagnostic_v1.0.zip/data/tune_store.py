"""
Tune Profile Storage — In-App
Stores all 10 tune profiles directly in the application.
Profiles can be activated, deactivated, modified, and reverted.
"""

import json
import os
import time
import copy
from data.n14_params import DEFAULT_TUNE_PROFILES, TUNABLE_PARAMS


class TuneStore:
    def __init__(self, app_dir=None):
        if app_dir is None:
            app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.store_file = os.path.join(app_dir, "tune_profiles.json")
        self.backup_dir = os.path.join(app_dir, "tune_backups")
        self.profiles = {}
        self.active_profile_id = None
        self.change_history = []
        self._load()

    def _load(self):
        if os.path.exists(self.store_file):
            try:
                with open(self.store_file, "r") as f:
                    data = json.load(f)
                self.profiles = {int(k): v for k, v in data.get("profiles", {}).items()}
                self.active_profile_id = data.get("active_profile_id")
                self.change_history = data.get("change_history", [])
                return
            except Exception:
                pass
        self.profiles = copy.deepcopy(DEFAULT_TUNE_PROFILES)
        self.active_profile_id = 1
        self.change_history = []
        self._save()

    def _save(self):
        data = {
            "profiles": self.profiles,
            "active_profile_id": self.active_profile_id,
            "change_history": self.change_history[-500:],
            "last_saved": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        try:
            os.makedirs(os.path.dirname(self.store_file) or ".", exist_ok=True)
            with open(self.store_file, "w") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def get_all_profiles(self):
        return copy.deepcopy(self.profiles)

    def get_profile(self, profile_id):
        return copy.deepcopy(self.profiles.get(profile_id))

    def get_active_profile(self):
        if self.active_profile_id:
            return self.active_profile_id, copy.deepcopy(self.profiles.get(self.active_profile_id))
        return None, None

    def activate_profile(self, profile_id):
        if profile_id not in self.profiles:
            return {"status": "error", "message": "Profile {} does not exist".format(profile_id)}
        old_active = self.active_profile_id
        self._record_change("activate", profile_id, {"previous_active": old_active})
        if self.active_profile_id and self.active_profile_id in self.profiles:
            self.profiles[self.active_profile_id]["active"] = False
        self.profiles[profile_id]["active"] = True
        self.active_profile_id = profile_id
        self._save()
        profile = self.profiles[profile_id]
        return {
            "status": "activated", "profile_id": profile_id,
            "name": profile["name"], "params": profile["params"],
            "message": "Tune {} ({}) ACTIVATED".format(profile_id, profile["name"])
        }

    def deactivate_profile(self, profile_id):
        if profile_id not in self.profiles:
            return {"status": "error", "message": "Profile {} does not exist".format(profile_id)}
        self._record_change("deactivate", profile_id, {})
        self.profiles[profile_id]["active"] = False
        if self.active_profile_id == profile_id:
            self.profiles[1]["active"] = True
            self.active_profile_id = 1
        self._save()
        return {"status": "deactivated", "profile_id": profile_id, "reverted_to": 1}

    def update_profile(self, profile_id, name=None, description=None, params=None, color=None):
        if profile_id not in self.profiles:
            return {"status": "error", "message": "Profile {} does not exist".format(profile_id)}
        profile = self.profiles[profile_id]
        old_profile = copy.deepcopy(profile)
        if params:
            for key, value in params.items():
                if key not in TUNABLE_PARAMS:
                    return {"status": "error", "message": "Unknown parameter: {}".format(key)}
                p = TUNABLE_PARAMS[key]
                if value < p["min_safe"] or value > p["max_safe"]:
                    return {"status": "error", "message": "{}: {} outside safe range ({}-{} {})".format(
                        p["name"], value, p["min_safe"], p["max_safe"], p["unit"])}
            profile["params"].update(params)
        if name is not None: profile["name"] = name
        if description is not None: profile["description"] = description
        if color is not None: profile["color"] = color
        self._record_change("update", profile_id, {"old": old_profile, "new": copy.deepcopy(profile)})
        self._save()
        return {"status": "updated", "profile_id": profile_id, "name": profile["name"]}

    def reset_profile(self, profile_id):
        if profile_id not in DEFAULT_TUNE_PROFILES:
            return {"status": "error", "message": "No factory default for profile {}".format(profile_id)}
        old = copy.deepcopy(self.profiles.get(profile_id))
        self._record_change("reset", profile_id, {"old": old})
        self.profiles[profile_id] = copy.deepcopy(DEFAULT_TUNE_PROFILES[profile_id])
        self._save()
        return {"status": "reset", "profile_id": profile_id}

    def revert_last_change(self):
        if not self.change_history:
            return {"status": "error", "message": "No changes to revert"}
        last = self.change_history.pop()
        action, pid = last["action"], last["profile_id"]
        if action == "activate":
            prev = last["data"].get("previous_active")
            self.profiles[pid]["active"] = False
            target = prev if prev and prev in self.profiles else 1
            self.profiles[target]["active"] = True
            self.active_profile_id = target
        elif action == "update":
            old = last["data"].get("old")
            if old: self.profiles[pid] = old
        elif action == "reset":
            old = last["data"].get("old")
            if old: self.profiles[pid] = old
        elif action == "deactivate":
            self.profiles[pid]["active"] = True
            self.active_profile_id = pid
        self._save()
        return {"status": "reverted", "action_reverted": action, "profile_id": pid}

    def create_backup(self, label=""):
        os.makedirs(self.backup_dir, exist_ok=True)
        ts = time.strftime("%Y%m%d_%H%M%S")
        fn = "tune_backup_{}{}.json".format(ts, "_" + label if label else "")
        fp = os.path.join(self.backup_dir, fn)
        with open(fp, "w") as f:
            json.dump({"profiles": copy.deepcopy(self.profiles),
                       "active_profile_id": self.active_profile_id,
                       "backup_time": time.strftime("%Y-%m-%d %H:%M:%S"), "label": label}, f, indent=2)
        return {"status": "backed_up", "file": fp}

    def restore_backup(self, filepath):
        if not os.path.exists(filepath):
            return {"status": "error", "message": "Backup file not found"}
        self.create_backup(label="pre_restore")
        with open(filepath, "r") as f:
            data = json.load(f)
        self.profiles = {int(k): v for k, v in data.get("profiles", {}).items()}
        self.active_profile_id = data.get("active_profile_id", 1)
        self._save()
        return {"status": "restored"}

    def compare_profiles(self, id_a, id_b):
        a, b = self.profiles.get(id_a), self.profiles.get(id_b)
        if not a or not b: return {"status": "error"}
        diffs = []
        for key in TUNABLE_PARAMS:
            va, vb = a["params"].get(key), b["params"].get(key)
            if va != vb:
                p = TUNABLE_PARAMS[key]
                diffs.append({"param": p["name"], "unit": p["unit"],
                              "tune_a": va, "tune_b": vb, "diff": round((vb or 0) - (va or 0), 2)})
        return {"tune_a": {"id": id_a, "name": a["name"]}, "tune_b": {"id": id_b, "name": b["name"]},
                "differences": diffs}

    def _record_change(self, action, profile_id, data):
        self.change_history.append({"action": action, "profile_id": profile_id,
                                     "data": data, "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")})
