"""
ROTS Trucking — Peterbilt 379 Diagnostic Suite
Version 1.0 — READ-ONLY MODE

1996 Peterbilt 379 / Cummins N14 Celect Plus
Protocol: J1708/J1587 via USB OBD-II adapter

THIS VERSION IS READ-ONLY:
  - Reads all engine sensor data (RPM, boost, temps, pressures, etc.)
  - Reads diagnostic trouble codes (DTCs / check engine codes)
  - Logs all data to CSV files
  - Displays live gauges
  - NO ECM writes — NO parameter changes — NO code clearing
  - Your ECM is 100% safe

Usage:
  1. Plug in USB OBD-II adapter (Vgate vLinker FS or ELM327)
  2. Connect adapter to truck via 6-pin Deutsch connector
  3. Turn truck key to ON (engine can be off or running)
  4. Run this program: python main.py
  5. Go to 'Connect' tab, click AUTO-DETECT or select port manually
  6. Dashboard will show live engine data
  7. Go to 'Check Codes' tab to read fault codes

Requirements:
  pip install PyQt5 pyserial
"""

import sys
import os
import time

from PyQt5.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget,
                              QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                              QStatusBar, QAction, QMessageBox, QMenuBar)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QIcon

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comms.j1708 import J1708Connection
from data.logger import DataLogger
from ui.styles import DARK_THEME
from ui.dashboard import DashboardPanel
from ui.dtc_panel import DTCPanel
from ui.connection_panel import ConnectionPanel


class PeterbiltDiagnostic(QMainWindow):
    """Main application window — READ-ONLY diagnostic suite."""

    VERSION = "1.0 READ-ONLY"
    TITLE = "ROTS Trucking — Peterbilt 379 Diagnostic Suite"

    def __init__(self):
        super().__init__()
        self.setWindowTitle("{} v{}".format(self.TITLE, self.VERSION))
        self.setMinimumSize(1024, 700)
        self.resize(1280, 800)

        # Core systems
        self.j1708 = J1708Connection()
        self.logger = DataLogger()

        # Register logger callbacks
        self.j1708.on_data_update(self._on_data_update)
        self.j1708.on_dtc(self._on_dtc)
        self.j1708.on_connection_change(self._on_connection_change)

        # Logging state
        self.log_active = False
        self.log_timer = QTimer(self)
        self.log_timer.timeout.connect(self._log_snapshot)
        self.log_interval = 1000  # 1 second

        # Build UI
        self._setup_menu()
        self._setup_tabs()
        self._setup_statusbar()

        # Apply dark theme
        self.setStyleSheet(DARK_THEME)

    def _setup_menu(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")

        start_log = QAction("Start Data Logging", self)
        start_log.triggered.connect(self._start_logging)
        file_menu.addAction(start_log)

        stop_log = QAction("Stop Data Logging", self)
        stop_log.triggered.connect(self._stop_logging)
        file_menu.addAction(stop_log)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Help menu
        help_menu = menubar.addMenu("Help")

        about = QAction("About", self)
        about.triggered.connect(self._show_about)
        help_menu.addAction(about)

        safety = QAction("Safety Information", self)
        safety.triggered.connect(self._show_safety)
        help_menu.addAction(safety)

    def _setup_tabs(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Tab 1: Connection
        self.connection_panel = ConnectionPanel(self.j1708)
        self.tabs.addTab(self.connection_panel, "Connect")

        # Tab 2: Dashboard (all gauges)
        self.dashboard = DashboardPanel(self.j1708)
        self.tabs.addTab(self.dashboard, "Dashboard")

        # Tab 3: DTC Reader
        self.dtc_panel = DTCPanel(self.j1708)
        self.tabs.addTab(self.dtc_panel, "Check Codes")

        # Tab 4: Data log viewer
        self.log_panel = self._create_log_panel()
        self.tabs.addTab(self.log_panel, "Data Log")

    def _create_log_panel(self):
        """Simple panel showing logging status and controls."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(15)

        title = QLabel("CSV DATA LOGGING")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #e94560;")
        layout.addWidget(title)

        desc = QLabel(
            "Records all engine sensor data to CSV files on your laptop.\n"
            "Great for tracking engine health over time, reviewing trip data,\n"
            "or documenting issues for your mechanic.")
        desc.setStyleSheet("color: #a0a0c0; font-size: 13px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Controls
        btn_row = QHBoxLayout()

        self.log_start_btn = QPushButton("START LOGGING")
        self.log_start_btn.setStyleSheet(
            "QPushButton { background: #27ae60; color: white; padding: 14px 30px; "
            "font-size: 14px; font-weight: bold; border-radius: 8px; }"
            "QPushButton:hover { background: #2ecc71; }")
        self.log_start_btn.clicked.connect(self._start_logging)
        btn_row.addWidget(self.log_start_btn)

        self.log_stop_btn = QPushButton("STOP LOGGING")
        self.log_stop_btn.setStyleSheet(
            "QPushButton { background: #c0392b; color: white; padding: 14px 30px; "
            "font-size: 14px; font-weight: bold; border-radius: 8px; }"
            "QPushButton:hover { background: #e74c3c; }"
            "QPushButton:disabled { background: #333355; color: #666; }")
        self.log_stop_btn.clicked.connect(self._stop_logging)
        self.log_stop_btn.setEnabled(False)
        btn_row.addWidget(self.log_stop_btn)

        layout.addLayout(btn_row)

        # Status
        self.log_status = QLabel("Logging: INACTIVE")
        self.log_status.setStyleSheet(
            "color: #a0a0c0; font-size: 16px; font-weight: bold; padding: 10px;")
        layout.addWidget(self.log_status)

        self.log_file_label = QLabel("")
        self.log_file_label.setStyleSheet("color: #666688; font-size: 11px;")
        self.log_file_label.setWordWrap(True)
        layout.addWidget(self.log_file_label)

        # What gets logged
        info = QLabel(
            "DATA LOGGED:\n"
            "  - Engine data CSV: RPM, Boost, Oil Pressure, Coolant Temp, Oil Temp,\n"
            "    Fuel Temp, Fuel Pressure, Battery Voltage, Intake Temp, EGT,\n"
            "    Vehicle Speed, Throttle %, Engine Load %, Fuel Rate, Instant MPG,\n"
            "    Trans Temp, Turbo Speed, Coolant Level, Coolant Pressure, Ambient Temp\n"
            "  - DTC log CSV: All fault codes with timestamps\n"
            "  - Fuel economy CSV: Speed, RPM, fuel rate, MPG tracking\n\n"
            "Log files are saved in the 'logs' folder next to this program.")
        info.setStyleSheet(
            "color: #666688; font-size: 11px; font-family: Consolas; "
            "background: #0d1b2a; padding: 10px; border-radius: 4px;")
        layout.addWidget(info)

        layout.addStretch()
        return widget

    def _setup_statusbar(self):
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        self.sb_connection = QLabel("DISCONNECTED")
        self.sb_connection.setStyleSheet("color: #e74c3c; font-weight: bold; padding: 0 10px;")
        self.status_bar.addWidget(self.sb_connection)

        self.sb_mode = QLabel("READ-ONLY MODE")
        self.sb_mode.setStyleSheet(
            "color: #2ecc71; font-weight: bold; background: #0a2a0a; "
            "padding: 2px 8px; border-radius: 3px;")
        self.status_bar.addPermanentWidget(self.sb_mode)

        self.sb_version = QLabel("v{}".format(self.VERSION))
        self.sb_version.setStyleSheet("color: #666688; padding: 0 10px;")
        self.status_bar.addPermanentWidget(self.sb_version)

        # Status bar refresh
        self.sb_timer = QTimer(self)
        self.sb_timer.timeout.connect(self._update_statusbar)
        self.sb_timer.start(500)

    def _update_statusbar(self):
        if self.j1708.connected:
            self.sb_connection.setText("CONNECTED — {} on {}".format(
                self.j1708.adapter_type or "?", self.j1708.port or "?"))
            self.sb_connection.setStyleSheet(
                "color: #2ecc71; font-weight: bold; padding: 0 10px;")
        else:
            self.sb_connection.setText("DISCONNECTED")
            self.sb_connection.setStyleSheet(
                "color: #e74c3c; font-weight: bold; padding: 0 10px;")

    # ---- Callbacks ----

    def _on_data_update(self, key, value, old_value, timestamp):
        """Called when live data is updated."""
        pass  # Dashboard refreshes via its own timer

    def _on_dtc(self, dtc):
        """Called when a DTC is received."""
        if dtc.get("active") and dtc.get("severity") == "CRITICAL":
            # Flash status bar red for critical DTCs
            self.sb_connection.setStyleSheet(
                "color: #e74c3c; font-weight: bold; padding: 0 10px; background: #2a0a0a;")

    def _on_connection_change(self, connected):
        """Called when connection state changes."""
        if connected:
            self.connection_panel._log("Connection established — receiving data")
            # Auto-start requesting PIDs periodically
            if not hasattr(self, '_pid_timer'):
                self._pid_timer = QTimer(self)
                self._pid_timer.timeout.connect(self._request_pids)
                self._pid_timer.start(2000)  # Request all PIDs every 2s
        else:
            if hasattr(self, '_pid_timer'):
                self._pid_timer.stop()

    def _request_pids(self):
        """Periodically request all PIDs from ECM."""
        if self.j1708.connected:
            self.j1708.request_all_pids()

    # ---- Logging ----

    def _start_logging(self):
        if self.log_active:
            return
        result = self.logger.start_logging("peterbilt379")
        self.log_active = True
        self.log_timer.start(self.log_interval)
        self.log_start_btn.setEnabled(False)
        self.log_stop_btn.setEnabled(True)
        self.log_status.setText("Logging: ACTIVE")
        self.log_status.setStyleSheet(
            "color: #2ecc71; font-size: 16px; font-weight: bold; padding: 10px;")
        self.log_file_label.setText("Saving to: {}".format(
            result.get("data_file", "?")))

    def _stop_logging(self):
        if not self.log_active:
            return
        self.log_timer.stop()
        self.logger.stop_logging()
        self.log_active = False
        self.log_start_btn.setEnabled(True)
        self.log_stop_btn.setEnabled(False)
        self.log_status.setText("Logging: STOPPED")
        self.log_status.setStyleSheet(
            "color: #f39c12; font-size: 16px; font-weight: bold; padding: 10px;")

    def _log_snapshot(self):
        if self.log_active and self.j1708.connected:
            self.logger.log_data_snapshot(self.j1708.live_data)

    # ---- Help ----

    def _show_about(self):
        QMessageBox.information(self, "About",
            "ROTS Trucking — Peterbilt 379 Diagnostic Suite\n"
            "Version {}\n\n"
            "Vehicle: 1996 Peterbilt 379\n"
            "Engine: Cummins N14 Celect Plus\n"
            "VIN: 1XP5D68X3TD371440\n\n"
            "Protocol: SAE J1708/J1587\n"
            "Adapter: Vgate vLinker FS OBD2 USB\n\n"
            "This is a READ-ONLY diagnostic tool.\n"
            "No ECM parameters can be modified in this version.".format(self.VERSION))

    def _show_safety(self):
        QMessageBox.information(self, "Safety Information",
            "SAFETY INFORMATION\n"
            "{'=' * 40}\n\n"
            "This version operates in READ-ONLY mode:\n\n"
            "  SAFE: Read engine sensor data\n"
            "  SAFE: Read diagnostic trouble codes\n"
            "  SAFE: Log data to CSV files\n"
            "  SAFE: View live gauges\n\n"
            "  BLOCKED: Write ECM parameters\n"
            "  BLOCKED: Clear fault codes\n"
            "  BLOCKED: Change tune settings\n"
            "  BLOCKED: Modify any ECM data\n\n"
            "The J1708 bus is a shared data bus. Reading from it\n"
            "does NOT affect the ECM in any way. This is the same\n"
            "thing your dashboard gauges do — listen to the bus.\n\n"
            "Your ECM is 100% safe with this tool.")

    def closeEvent(self, event):
        """Clean shutdown."""
        if self.log_active:
            self._stop_logging()
        if self.j1708.connected:
            self.j1708.disconnect()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Peterbilt 379 Diagnostic Suite")
    app.setOrganizationName("ROTS Trucking LLC")
    app.setStyle("Fusion")

    window = PeterbiltDiagnostic()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
