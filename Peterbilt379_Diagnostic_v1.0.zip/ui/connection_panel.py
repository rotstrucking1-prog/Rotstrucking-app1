"""
Connection Panel — Port Selection & Adapter Connection
Handles USB adapter detection and J1708 bus connection.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QPushButton, QComboBox, QGroupBox, QFrame,
                              QTextEdit, QGridLayout, QSizePolicy)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont


class ConnectionPanel(QWidget):
    """USB adapter connection management panel."""

    def __init__(self, j1708_conn, parent=None):
        super().__init__(parent)
        self.conn = j1708_conn
        self._setup_ui()
        self._setup_refresh()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(15)

        # Title
        title = QLabel("CONNECTION SETUP")
        title.setObjectName("title")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #e94560;")
        layout.addWidget(title)

        # Safety banner
        safety = QLabel(
            "READ-ONLY MODE — This version can ONLY read data from your ECM.\n"
            "No parameters will be written. No codes will be cleared. Your ECM is safe.")
        safety.setStyleSheet(
            "background: #0a2a0a; color: #2ecc71; padding: 12px; "
            "border: 2px solid #2ecc71; border-radius: 8px; "
            "font-size: 13px; font-weight: bold;")
        safety.setAlignment(Qt.AlignCenter)
        safety.setWordWrap(True)
        layout.addWidget(safety)

        # Port selection
        port_group = QGroupBox("USB Adapter Port")
        port_layout = QVBoxLayout(port_group)

        port_row = QHBoxLayout()
        self.port_combo = QComboBox()
        self.port_combo.setMinimumWidth(300)
        self.port_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        port_row.addWidget(self.port_combo)

        self.scan_btn = QPushButton("Scan Ports")
        self.scan_btn.clicked.connect(self._scan_ports)
        self.scan_btn.setStyleSheet(
            "background: #0f3460; color: white; padding: 8px 16px; "
            "font-weight: bold; border-radius: 4px;")
        port_row.addWidget(self.scan_btn)
        port_layout.addLayout(port_row)

        self.port_info = QLabel("Click 'Scan Ports' to detect USB adapters")
        self.port_info.setStyleSheet("color: #a0a0c0; font-size: 11px; font-style: italic;")
        port_layout.addWidget(self.port_info)
        layout.addWidget(port_group)

        # Connect / Disconnect buttons
        btn_row = QHBoxLayout()

        self.connect_btn = QPushButton("CONNECT")
        self.connect_btn.setStyleSheet(
            "QPushButton { background: #27ae60; color: white; padding: 14px 40px; "
            "font-size: 16px; font-weight: bold; border-radius: 8px; }"
            "QPushButton:hover { background: #2ecc71; }"
            "QPushButton:disabled { background: #333355; color: #666; }")
        self.connect_btn.clicked.connect(self._connect)
        btn_row.addWidget(self.connect_btn)

        self.auto_btn = QPushButton("AUTO-DETECT")
        self.auto_btn.setStyleSheet(
            "QPushButton { background: #0f3460; color: white; padding: 14px 40px; "
            "font-size: 16px; font-weight: bold; border-radius: 8px; }"
            "QPushButton:hover { background: #533483; }"
            "QPushButton:disabled { background: #333355; color: #666; }")
        self.auto_btn.clicked.connect(self._auto_connect)
        btn_row.addWidget(self.auto_btn)

        self.disconnect_btn = QPushButton("DISCONNECT")
        self.disconnect_btn.setStyleSheet(
            "QPushButton { background: #c0392b; color: white; padding: 14px 40px; "
            "font-size: 16px; font-weight: bold; border-radius: 8px; }"
            "QPushButton:hover { background: #e74c3c; }"
            "QPushButton:disabled { background: #333355; color: #666; }")
        self.disconnect_btn.clicked.connect(self._disconnect)
        self.disconnect_btn.setEnabled(False)
        btn_row.addWidget(self.disconnect_btn)

        layout.addLayout(btn_row)

        # Connection status
        status_group = QGroupBox("Connection Status")
        status_layout = QGridLayout(status_group)

        labels = ["Status:", "Port:", "Adapter:", "Messages RX:", "Messages TX:",
                   "Errors:", "Live Parameters:", "Active DTCs:"]
        self.status_values = {}

        for i, label in enumerate(labels):
            row = i // 2
            col = (i % 2) * 2
            lbl = QLabel(label)
            lbl.setStyleSheet("color: #a0a0c0; font-weight: bold;")
            val = QLabel("—")
            val.setStyleSheet("color: #e0e0e0; font-family: Consolas;")
            self.status_values[label] = val
            status_layout.addWidget(lbl, row, col)
            status_layout.addWidget(val, row, col + 1)

        layout.addWidget(status_group)

        # Log output
        log_group = QGroupBox("Connection Log")
        log_layout = QVBoxLayout(log_group)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(200)
        self.log_text.setStyleSheet(
            "background: #0d1b2a; color: #00ff88; font-family: Consolas; font-size: 11px;")
        log_layout.addWidget(self.log_text)
        layout.addWidget(log_group)

        # Hardware info at bottom
        hw_info = QLabel(
            "Compatible adapters: ELM327 USB, Vgate vLinker FS, any J1708-compatible serial adapter\n"
            "Connection: Deutsch 6-pin (truck) -> OBD-II Y-adapter -> USB adapter -> Laptop\n"
            "Protocol: SAE J1708/J1587 @ 9600 baud")
        hw_info.setStyleSheet("color: #666688; font-size: 10px;")
        hw_info.setWordWrap(True)
        layout.addWidget(hw_info)

        layout.addStretch()

    def _setup_refresh(self):
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._update_status)
        self.refresh_timer.start(1000)

    def _log(self, msg):
        import time
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.append("[{}] {}".format(timestamp, msg))

    def _scan_ports(self):
        """Scan for available COM ports."""
        self.port_combo.clear()
        self._log("Scanning USB ports...")

        ports = self.conn.scan_ports()
        if not ports:
            self.port_combo.addItem("No ports found — check USB connection")
            self.port_info.setText("No USB serial ports detected. Is the adapter plugged in?")
            self.port_info.setStyleSheet("color: #e74c3c; font-size: 11px; font-weight: bold;")
            self._log("No ports found")
            return

        for p in ports:
            label = "{} — {} [{}]".format(p["port"], p["description"], p["adapter_type"])
            if p["is_compatible"]:
                label = "* " + label
            self.port_combo.addItem(label, p["port"])

        compatible = [p for p in ports if p["is_compatible"]]
        self.port_info.setText("Found {} port(s), {} compatible".format(
            len(ports), len(compatible)))
        self.port_info.setStyleSheet("color: #2ecc71; font-size: 11px;")
        self._log("Found {} port(s), {} compatible".format(len(ports), len(compatible)))

    def _connect(self):
        """Connect to the selected port."""
        port = self.port_combo.currentData()
        if not port:
            self._log("ERROR: No port selected")
            return

        self._log("Connecting to {}...".format(port))
        result = self.conn.connect(port=port, auto=False)
        self._handle_connect_result(result)

    def _auto_connect(self):
        """Auto-detect and connect to the best available adapter."""
        self._log("Auto-detecting adapter...")
        result = self.conn.connect(auto=True)
        self._handle_connect_result(result)

    def _handle_connect_result(self, result):
        status = result.get("status", "error")
        msg = result.get("message", "Unknown error")

        if status in ("connected",):
            self._log("CONNECTED: {}".format(msg))
            self.connect_btn.setEnabled(False)
            self.auto_btn.setEnabled(False)
            self.disconnect_btn.setEnabled(True)

            # Start requesting all PIDs
            self._log("Requesting engine data...")
            self.conn.request_all_pids()
        else:
            self._log("ERROR: {}".format(msg))
            ports_found = result.get("ports_found", [])
            if ports_found:
                self._log("Available ports: {}".format(", ".join(ports_found)))

    def _disconnect(self):
        """Disconnect from the adapter."""
        self._log("Disconnecting...")
        result = self.conn.disconnect()
        self._log(result.get("message", "Disconnected"))
        self.connect_btn.setEnabled(True)
        self.auto_btn.setEnabled(True)
        self.disconnect_btn.setEnabled(False)

    def _update_status(self):
        """Update the status display."""
        s = self.conn.get_status()

        connected = s.get("connected", False)
        self.status_values["Status:"].setText("CONNECTED" if connected else "DISCONNECTED")
        self.status_values["Status:"].setStyleSheet(
            "color: {}; font-family: Consolas; font-weight: bold;".format(
                "#2ecc71" if connected else "#e74c3c"))

        self.status_values["Port:"].setText(s.get("port") or "—")
        self.status_values["Adapter:"].setText(s.get("adapter") or "—")
        self.status_values["Messages RX:"].setText("{:,}".format(s.get("messages_received", 0)))
        self.status_values["Messages TX:"].setText("{:,}".format(s.get("messages_sent", 0)))
        self.status_values["Errors:"].setText(str(s.get("errors", 0)))
        self.status_values["Live Parameters:"].setText(str(s.get("live_params", 0)))
        self.status_values["Active DTCs:"].setText(str(s.get("active_dtcs", 0)))
