"""
Dashboard — All Gauges View
Shows all gauges simultaneously or individually selectable.
Includes real-time data display with status indicators.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                              QLabel, QPushButton, QComboBox, QCheckBox,
                              QGroupBox, QScrollArea, QSizePolicy, QFrame)
from PyQt5.QtCore import Qt, QTimer
from ui.gauge_widget import GaugeWidget, DigitalGaugeWidget
from data.n14_params import PIDS


class DashboardPanel(QWidget):
    """Main dashboard with all gauges."""

    def __init__(self, j1708_conn, parent=None):
        super().__init__(parent)
        self.conn = j1708_conn
        self.gauges = {}
        self.digital_gauges = {}
        self.all_visible = True

        self._setup_ui()
        self._setup_refresh_timer()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(5)

        # Top bar — view controls
        top_bar = QHBoxLayout()

        self.view_combo = QComboBox()
        self.view_combo.addItem("All Gauges")
        self.view_combo.addItem("Engine Core")
        self.view_combo.addItem("Temperatures")
        self.view_combo.addItem("Electrical")
        self.view_combo.addItem("Fuel & Economy")
        self.view_combo.addItem("Individual Gauge")
        self.view_combo.currentIndexChanged.connect(self._on_view_changed)
        top_bar.addWidget(QLabel("View:"))
        top_bar.addWidget(self.view_combo)

        self.individual_combo = QComboBox()
        for key in sorted(PIDS.keys()):
            self.individual_combo.addItem(PIDS[key]["name"], key)
        self.individual_combo.currentIndexChanged.connect(self._on_individual_changed)
        self.individual_combo.setVisible(False)
        top_bar.addWidget(self.individual_combo)

        top_bar.addStretch()

        # Connection status
        self.status_label = QLabel("DISCONNECTED")
        self.status_label.setStyleSheet(
            "color: #e74c3c; font-weight: bold; padding: 4px 12px; "
            "background: #2a0a0a; border-radius: 4px;")
        top_bar.addWidget(self.status_label)

        # Message count
        self.msg_label = QLabel("Msgs: 0")
        self.msg_label.setStyleSheet("color: #a0a0c0; font-size: 11px;")
        top_bar.addWidget(self.msg_label)

        main_layout.addLayout(top_bar)

        # Scroll area for gauges
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        self.gauge_container = QWidget()
        self.gauge_layout = QGridLayout(self.gauge_container)
        self.gauge_layout.setSpacing(8)
        scroll.setWidget(self.gauge_container)
        main_layout.addWidget(scroll)

        # Create all gauges
        self._create_gauges()

        # Status bar at bottom
        self.bottom_bar = QHBoxLayout()
        self.dtc_label = QLabel("DTCs: None")
        self.dtc_label.setStyleSheet("color: #2ecc71; font-weight: bold;")
        self.bottom_bar.addWidget(self.dtc_label)
        self.bottom_bar.addStretch()
        self.elapsed_label = QLabel("Uptime: 00:00:00")
        self.elapsed_label.setStyleSheet("color: #a0a0c0;")
        self.bottom_bar.addWidget(self.elapsed_label)
        main_layout.addLayout(self.bottom_bar)

    def _create_gauges(self):
        """Create all gauge widgets based on PID definitions."""
        # Main analog gauges — these get the big circular display
        analog_pids = [
            "RPM", "BOOST", "OIL_PRESS", "COOLANT_TEMP", "OIL_TEMP",
            "FUEL_PRESS", "BATTERY_VOLTS", "EXHAUST_TEMP", "VEHICLE_SPEED",
            "THROTTLE_POS", "ENGINE_LOAD", "INSTANT_MPG"
        ]

        # Digital-only gauges
        digital_pids = [
            "FUEL_TEMP", "INTAKE_TEMP", "ALT_CURRENT", "FUEL_RATE",
            "TRANS_TEMP", "TURBO_SPEED", "COOLANT_LEVEL", "COOLANT_PRESS",
            "AMBIENT_TEMP", "ENGINE_HOURS", "TOTAL_FUEL"
        ]

        row, col = 0, 0
        max_cols = 4

        for key in analog_pids:
            if key not in PIDS:
                continue
            p = PIDS[key]
            low_danger = key in ["OIL_PRESS", "FUEL_PRESS", "BATTERY_VOLTS",
                                  "COOLANT_LEVEL", "COOLANT_PRESS", "INSTANT_MPG"]
            gauge = GaugeWidget(
                name=p["name"], unit=p["unit"],
                min_val=p["min"], max_val=p["max"],
                warning=p.get("warning"), critical=p.get("critical"),
                low_danger=low_danger
            )
            self.gauges[key] = gauge
            self.gauge_layout.addWidget(gauge, row, col)
            col += 1
            if col >= max_cols:
                col = 0
                row += 1

        # Digital gauges in a row below
        row += 1
        col = 0
        for key in digital_pids:
            if key not in PIDS:
                continue
            p = PIDS[key]
            dg = DigitalGaugeWidget(name=p["name"], unit=p["unit"])
            self.digital_gauges[key] = dg
            self.gauge_layout.addWidget(dg, row, col)
            col += 1
            if col >= max_cols:
                col = 0
                row += 1

    def _setup_refresh_timer(self):
        """Timer to refresh gauge values from live data."""
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._refresh_gauges)
        self.refresh_timer.start(100)  # 10Hz refresh

    def _refresh_gauges(self):
        """Update all gauge values from J1708 live data."""
        live = self.conn.live_data

        # Update analog gauges
        for key, gauge in self.gauges.items():
            data = live.get(key)
            if data:
                gauge.set_value(data["value"])

        # Update digital gauges
        for key, dg in self.digital_gauges.items():
            data = live.get(key)
            if data:
                dg.set_value(data["value"], data.get("status", "NORMAL"))

        # Update status indicators
        status = self.conn.get_status()
        if status["connected"]:
            self.status_label.setText("CONNECTED")
            self.status_label.setStyleSheet(
                "color: #2ecc71; font-weight: bold; padding: 4px 12px; "
                "background: #0a2a0a; border-radius: 4px;")
        else:
            self.status_label.setText("DISCONNECTED")
            self.status_label.setStyleSheet(
                "color: #e74c3c; font-weight: bold; padding: 4px 12px; "
                "background: #2a0a0a; border-radius: 4px;")

        self.msg_label.setText("Msgs: {:,}".format(status["messages_received"]))

        # DTC status
        num_active = len(self.conn.active_dtcs)
        if num_active > 0:
            self.dtc_label.setText("DTCs: {} ACTIVE".format(num_active))
            self.dtc_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
        else:
            self.dtc_label.setText("DTCs: None")
            self.dtc_label.setStyleSheet("color: #2ecc71; font-weight: bold;")

    def _on_view_changed(self, index):
        """Handle view mode change."""
        self.individual_combo.setVisible(index == 5)

        # Define which gauges show in each view
        views = {
            0: None,  # All
            1: ["RPM", "BOOST", "OIL_PRESS", "COOLANT_TEMP", "THROTTLE_POS", "ENGINE_LOAD"],
            2: ["COOLANT_TEMP", "OIL_TEMP", "FUEL_TEMP", "INTAKE_TEMP", "EXHAUST_TEMP", "TRANS_TEMP", "AMBIENT_TEMP"],
            3: ["BATTERY_VOLTS", "ALT_CURRENT", "ENGINE_LOAD"],
            4: ["FUEL_PRESS", "FUEL_RATE", "INSTANT_MPG", "VEHICLE_SPEED", "TOTAL_FUEL"],
        }

        if index == 5:
            # Individual — handled by _on_individual_changed
            self._on_individual_changed(self.individual_combo.currentIndex())
            return

        visible_keys = views.get(index)

        for key, gauge in self.gauges.items():
            gauge.setVisible(visible_keys is None or key in visible_keys)
        for key, dg in self.digital_gauges.items():
            dg.setVisible(visible_keys is None or key in visible_keys)

    def _on_individual_changed(self, index):
        """Show only the selected individual gauge."""
        selected_key = self.individual_combo.currentData()
        for key, gauge in self.gauges.items():
            gauge.setVisible(key == selected_key)
        for key, dg in self.digital_gauges.items():
            dg.setVisible(key == selected_key)
