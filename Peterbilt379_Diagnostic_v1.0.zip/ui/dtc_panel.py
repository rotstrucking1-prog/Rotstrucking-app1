"""
DTC (Diagnostic Trouble Code) Reader Panel
Displays active and inactive fault codes from the N14 ECM.
READ-ONLY — reads codes only, no clearing capability in this version.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget,
                              QTableWidgetItem, QPushButton, QLabel, QGroupBox,
                              QHeaderView, QFrame, QTextEdit, QSplitter)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QFont, QIcon
from data.n14_params import DTC_CODES


class DTCPanel(QWidget):
    """Diagnostic Trouble Code reader and display panel."""

    def __init__(self, j1708_conn, parent=None):
        super().__init__(parent)
        self.conn = j1708_conn
        self._setup_ui()
        self._setup_refresh()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        # Title bar
        title_bar = QHBoxLayout()
        title = QLabel("ENGINE DIAGNOSTIC CODES")
        title.setObjectName("title")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #e94560;")
        title_bar.addWidget(title)

        title_bar.addStretch()

        # Read codes button
        self.read_btn = QPushButton("  READ CODES")
        self.read_btn.setStyleSheet(
            "QPushButton { background: #0f3460; color: white; padding: 10px 20px; "
            "font-size: 14px; font-weight: bold; border-radius: 6px; }"
            "QPushButton:hover { background: #533483; }"
            "QPushButton:disabled { background: #333355; color: #666; }")
        self.read_btn.clicked.connect(self._read_codes)
        title_bar.addWidget(self.read_btn)

        layout.addLayout(title_bar)

        # Status summary
        self.summary_frame = QFrame()
        self.summary_frame.setStyleSheet(
            "background: #16213e; border: 1px solid #333355; border-radius: 8px; padding: 10px;")
        summary_layout = QHBoxLayout(self.summary_frame)

        self.active_count = QLabel("0")
        self.active_count.setStyleSheet("color: #2ecc71; font-size: 36px; font-weight: bold;")
        self.active_label = QLabel("Active Codes")
        self.active_label.setStyleSheet("color: #a0a0c0; font-size: 12px;")
        active_box = QVBoxLayout()
        active_box.addWidget(self.active_count, alignment=Qt.AlignCenter)
        active_box.addWidget(self.active_label, alignment=Qt.AlignCenter)

        self.inactive_count = QLabel("0")
        self.inactive_count.setStyleSheet("color: #f39c12; font-size: 36px; font-weight: bold;")
        self.inactive_label = QLabel("Stored / Inactive")
        self.inactive_label.setStyleSheet("color: #a0a0c0; font-size: 12px;")
        inactive_box = QVBoxLayout()
        inactive_box.addWidget(self.inactive_count, alignment=Qt.AlignCenter)
        inactive_box.addWidget(self.inactive_label, alignment=Qt.AlignCenter)

        self.status_icon = QLabel("ALL CLEAR")
        self.status_icon.setStyleSheet(
            "color: #2ecc71; font-size: 24px; font-weight: bold; "
            "background: #0a2a0a; padding: 15px 25px; border-radius: 8px;")
        self.status_icon.setAlignment(Qt.AlignCenter)

        summary_layout.addLayout(active_box)
        summary_layout.addWidget(self._make_separator())
        summary_layout.addLayout(inactive_box)
        summary_layout.addWidget(self._make_separator())
        summary_layout.addWidget(self.status_icon)
        layout.addWidget(self.summary_frame)

        # Splitter for active and inactive tables
        splitter = QSplitter(Qt.Vertical)

        # Active DTCs table
        active_group = QGroupBox("ACTIVE FAULT CODES (Current Problems)")
        active_group.setStyleSheet(
            "QGroupBox { border: 2px solid #e74c3c; border-radius: 6px; margin-top: 10px; "
            "padding-top: 15px; font-weight: bold; color: #e74c3c; }")
        active_layout = QVBoxLayout(active_group)
        self.active_table = self._create_dtc_table()
        active_layout.addWidget(self.active_table)
        splitter.addWidget(active_group)

        # Inactive DTCs table
        inactive_group = QGroupBox("STORED / INACTIVE CODES (Past Problems)")
        inactive_group.setStyleSheet(
            "QGroupBox { border: 2px solid #f39c12; border-radius: 6px; margin-top: 10px; "
            "padding-top: 15px; font-weight: bold; color: #f39c12; }")
        inactive_layout = QVBoxLayout(inactive_group)
        self.inactive_table = self._create_dtc_table()
        inactive_layout.addWidget(self.inactive_table)
        splitter.addWidget(inactive_group)

        layout.addWidget(splitter)

        # Detail panel at bottom
        detail_group = QGroupBox("CODE DETAILS")
        detail_layout = QVBoxLayout(detail_group)
        self.detail_text = QTextEdit()
        self.detail_text.setReadOnly(True)
        self.detail_text.setMaximumHeight(120)
        self.detail_text.setPlaceholderText(
            "Click a code above to see full details, severity, and recommended action...")
        detail_layout.addWidget(self.detail_text)
        layout.addWidget(detail_group)

        # Last scan info
        self.scan_info = QLabel("No scan performed yet — click READ CODES to scan ECM")
        self.scan_info.setStyleSheet("color: #666688; font-size: 11px; font-style: italic;")
        layout.addWidget(self.scan_info)

    def _create_dtc_table(self):
        table = QTableWidget(0, 5)
        table.setHorizontalHeaderLabels(["Code", "FMI", "Description", "Severity", "Action"])
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        header.setSectionResizeMode(1, QHeaderView.Fixed)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.Fixed)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        table.setColumnWidth(0, 60)
        table.setColumnWidth(1, 50)
        table.setColumnWidth(3, 90)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.cellClicked.connect(self._on_cell_clicked)
        return table

    def _make_separator(self):
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color: #333355;")
        return sep

    def _setup_refresh(self):
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._update_display)
        self.refresh_timer.start(2000)

    def _read_codes(self):
        """Request DTCs from the ECM."""
        if not self.conn.connected:
            self.scan_info.setText("NOT CONNECTED — Connect to ECM first")
            self.scan_info.setStyleSheet("color: #e74c3c; font-size: 11px; font-weight: bold;")
            return

        self.read_btn.setEnabled(False)
        self.read_btn.setText("  SCANNING...")
        self.scan_info.setText("Requesting codes from ECM...")

        result = self.conn.read_dtcs()
        self._populate_tables()

        import time
        self.scan_info.setText("Scan completed at {} — {} active, {} stored".format(
            time.strftime("%I:%M:%S %p"),
            len(self.conn.active_dtcs),
            len(self.conn.inactive_dtcs)))
        self.scan_info.setStyleSheet("color: #2ecc71; font-size: 11px;")

        self.read_btn.setEnabled(True)
        self.read_btn.setText("  READ CODES")

    def _populate_tables(self):
        """Fill tables with current DTC data."""
        self._fill_table(self.active_table, self.conn.active_dtcs)
        self._fill_table(self.inactive_table, self.conn.inactive_dtcs)

    def _fill_table(self, table, dtc_list):
        table.setRowCount(len(dtc_list))
        for i, dtc in enumerate(dtc_list):
            code_item = QTableWidgetItem(str(dtc.get("code", "?")))
            fmi_item = QTableWidgetItem(str(dtc.get("fmi", "?")))
            desc_item = QTableWidgetItem(dtc.get("description", "Unknown"))
            severity = dtc.get("severity", "UNKNOWN")
            sev_item = QTableWidgetItem(severity)
            action_item = QTableWidgetItem(dtc.get("action", ""))

            # Color by severity
            colors = {
                "CRITICAL": QColor("#e74c3c"),
                "WARNING": QColor("#f39c12"),
                "INFO": QColor("#3498db"),
                "UNKNOWN": QColor("#a0a0c0"),
            }
            color = colors.get(severity, QColor("#a0a0c0"))
            for item in [code_item, fmi_item, desc_item, sev_item, action_item]:
                item.setForeground(color)

            sev_item.setFont(QFont("Segoe UI", 10, QFont.Bold))

            table.setItem(i, 0, code_item)
            table.setItem(i, 1, fmi_item)
            table.setItem(i, 2, desc_item)
            table.setItem(i, 3, sev_item)
            table.setItem(i, 4, action_item)

    def _update_display(self):
        """Update summary counts."""
        active = len(self.conn.active_dtcs)
        inactive = len(self.conn.inactive_dtcs)

        self.active_count.setText(str(active))
        self.inactive_count.setText(str(inactive))

        if active > 0:
            # Check if any are critical
            has_critical = any(d.get("severity") == "CRITICAL" for d in self.conn.active_dtcs)
            if has_critical:
                self.status_icon.setText("CRITICAL")
                self.status_icon.setStyleSheet(
                    "color: #e74c3c; font-size: 24px; font-weight: bold; "
                    "background: #2a0a0a; padding: 15px 25px; border-radius: 8px;")
                self.active_count.setStyleSheet(
                    "color: #e74c3c; font-size: 36px; font-weight: bold;")
            else:
                self.status_icon.setText("WARNING")
                self.status_icon.setStyleSheet(
                    "color: #f39c12; font-size: 24px; font-weight: bold; "
                    "background: #2a1a0a; padding: 15px 25px; border-radius: 8px;")
                self.active_count.setStyleSheet(
                    "color: #f39c12; font-size: 36px; font-weight: bold;")
        else:
            self.status_icon.setText("ALL CLEAR")
            self.status_icon.setStyleSheet(
                "color: #2ecc71; font-size: 24px; font-weight: bold; "
                "background: #0a2a0a; padding: 15px 25px; border-radius: 8px;")
            self.active_count.setStyleSheet(
                "color: #2ecc71; font-size: 36px; font-weight: bold;")

    def _on_cell_clicked(self, row, col):
        """Show detailed info about the clicked DTC."""
        table = self.sender()
        code_item = table.item(row, 0)
        if not code_item:
            return

        try:
            code = int(code_item.text())
        except ValueError:
            return

        info = DTC_CODES.get(code, {})
        desc = info.get("desc", "Unknown fault code")
        severity = info.get("severity", "UNKNOWN")
        action = info.get("action", "Refer to service manual")

        detail = (
            "CODE {code}\n"
            "{'=' * 40}\n"
            "Description: {desc}\n"
            "Severity:    {sev}\n"
            "Action:      {action}\n\n"
            "NOTE: This is a READ-ONLY scan. No codes have been modified or cleared."
        ).format(code=code, desc=desc, sev=severity, action=action)

        self.detail_text.setText(detail)
