"""
Fuel Economy Calculator
Real-time MPG calculation based on Speed + RPM (Option 2).
Tracks best RPM/speed zones for optimal fuel economy.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                              QLabel, QPushButton, QGroupBox, QTableWidget,
                              QTableWidgetItem, QHeaderView, QFrame)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QFont


class FuelCalcPanel(QWidget):
    """Real-time fuel economy calculator and optimizer."""

    def __init__(self, j1708_conn, logger, parent=None):
        super().__init__(parent)
        self.conn = j1708_conn
        self.logger = logger

        # Tracking data
        self.total_fuel_gal = 0.0
        self.total_miles = 0.0
        self.mpg_samples = []
        self.rpm_zone_data = {}  # rpm_bucket -> [mpg_samples]
        self.speed_zone_data = {}
        self.last_update_time = 0
        self.session_active = False

        self._setup_ui()
        self._setup_timer()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # Title
        title = QLabel("FUEL ECONOMY CALCULATOR")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #e94560;")
        layout.addWidget(title)

        subtitle = QLabel("Method: Speed + RPM Based Calculation (Option 2)")
        subtitle.setStyleSheet("color: #a0a0c0; font-size: 11px;")
        layout.addWidget(subtitle)

        # Live metrics row
        metrics = QHBoxLayout()

        # Instant MPG
        self.mpg_box = self._create_metric_box("INSTANT MPG", "0.0", "#2ecc71")
        metrics.addWidget(self.mpg_box["frame"])

        # Average MPG
        self.avg_mpg_box = self._create_metric_box("AVERAGE MPG", "0.0", "#3498db")
        metrics.addWidget(self.avg_mpg_box["frame"])

        # Fuel Rate
        self.fuel_rate_box = self._create_metric_box("FUEL RATE", "0.0 GPH", "#f39c12")
        metrics.addWidget(self.fuel_rate_box["frame"])

        # Total Fuel
        self.total_fuel_box = self._create_metric_box("SESSION FUEL", "0.0 gal", "#e74c3c")
        metrics.addWidget(self.total_fuel_box["frame"])

        # Total Miles
        self.total_miles_box = self._create_metric_box("SESSION MILES", "0.0 mi", "#9b59b6")
        metrics.addWidget(self.total_miles_box["frame"])

        # Cost per mile
        self.cpm_box = self._create_metric_box("FUEL COST/MI", "$0.00", "#e94560")
        metrics.addWidget(self.cpm_box["frame"])

        layout.addLayout(metrics)

        # Session controls
        ctrl_row = QHBoxLayout()

        self.start_btn = QPushButton("Start Tracking")
        self.start_btn.setObjectName("success")
        self.start_btn.clicked.connect(self._start_session)
        ctrl_row.addWidget(self.start_btn)

        self.stop_btn = QPushButton("Stop Tracking")
        self.stop_btn.setObjectName("danger")
        self.stop_btn.clicked.connect(self._stop_session)
        self.stop_btn.setEnabled(False)
        ctrl_row.addWidget(self.stop_btn)

        self.reset_btn = QPushButton("Reset")
        self.reset_btn.clicked.connect(self._reset_session)
        ctrl_row.addWidget(self.reset_btn)

        ctrl_row.addStretch()

        # Fuel price input
        ctrl_row.addWidget(QLabel("Fuel Price: $"))
        self.fuel_price_label = QLabel("4.65")
        self.fuel_price_label.setStyleSheet("color: #f39c12; font-weight: bold; font-size: 14px;")
        ctrl_row.addWidget(self.fuel_price_label)
        ctrl_row.addWidget(QLabel("/gal"))

        layout.addLayout(ctrl_row)

        # Best zones table
        zones_group = QGroupBox("OPTIMAL RPM/SPEED ZONES (Best Fuel Economy)")
        zones_layout = QVBoxLayout(zones_group)

        self.zones_table = QTableWidget()
        self.zones_table.setColumnCount(5)
        self.zones_table.setHorizontalHeaderLabels([
            "RPM Range", "Avg Speed (MPH)", "Avg MPG", "Samples", "Rating"
        ])
        self.zones_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        zones_layout.addWidget(self.zones_table)

        layout.addWidget(zones_group)

        # RPM Sweet Spot indicator
        self.sweetspot_label = QLabel("Best RPM Zone: Collecting data...")
        self.sweetspot_label.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #2ecc71; "
            "padding: 8px; background: #0a2a0a; border-radius: 4px; text-align: center;")
        self.sweetspot_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.sweetspot_label)

    def _create_metric_box(self, title, default_value, color):
        """Create a metric display box."""
        frame = QFrame()
        frame.setStyleSheet(
            "background: #16213e; border: 1px solid #333355; border-radius: 6px; padding: 8px;")
        frame_layout = QVBoxLayout(frame)
        frame_layout.setContentsMargins(8, 4, 8, 4)
        frame_layout.setSpacing(2)

        title_lbl = QLabel(title)
        title_lbl.setAlignment(Qt.AlignCenter)
        title_lbl.setStyleSheet("color: #a0a0c0; font-size: 9px; font-weight: bold; border: none;")

        value_lbl = QLabel(default_value)
        value_lbl.setAlignment(Qt.AlignCenter)
        value_lbl.setStyleSheet(
            "color: {}; font-size: 24px; font-weight: bold; font-family: Consolas; border: none;".format(color))

        frame_layout.addWidget(title_lbl)
        frame_layout.addWidget(value_lbl)

        return {"frame": frame, "value_label": value_lbl}

    def _setup_timer(self):
        """Timer for updating fuel calculations."""
        self.calc_timer = QTimer(self)
        self.calc_timer.timeout.connect(self._update_calculations)
        self.calc_timer.start(1000)  # 1Hz

    def _update_calculations(self):
        """Update all fuel economy calculations from live data."""
        live = self.conn.live_data

        speed = live.get("VEHICLE_SPEED", {}).get("value")
        rpm = live.get("RPM", {}).get("value")
        fuel_rate = live.get("FUEL_RATE", {}).get("value")
        instant_mpg = live.get("INSTANT_MPG", {}).get("value")

        # Update instant MPG
        if instant_mpg is not None:
            self.mpg_box["value_label"].setText("{:.1f}".format(instant_mpg))
            if instant_mpg >= 6.0:
                color = "#2ecc71"
            elif instant_mpg >= 5.0:
                color = "#f39c12"
            else:
                color = "#e74c3c"
            self.mpg_box["value_label"].setStyleSheet(
                "color: {}; font-size: 24px; font-weight: bold; font-family: Consolas; border: none;".format(color))

        # Update fuel rate
        if fuel_rate is not None:
            self.fuel_rate_box["value_label"].setText("{:.1f} GPH".format(fuel_rate))

        # Session tracking
        if self.session_active and speed is not None and fuel_rate is not None:
            import time
            now = time.time()
            if self.last_update_time > 0:
                dt_hours = (now - self.last_update_time) / 3600.0
                self.total_fuel_gal += fuel_rate * dt_hours
                self.total_miles += speed * dt_hours

            self.last_update_time = now

            # Track MPG samples
            if instant_mpg is not None and speed > 5:  # Only track while moving
                self.mpg_samples.append(instant_mpg)

                # Track by RPM zone
                if rpm is not None:
                    rpm_bucket = int(rpm / 100) * 100  # Round to nearest 100
                    if rpm_bucket not in self.rpm_zone_data:
                        self.rpm_zone_data[rpm_bucket] = []
                    self.rpm_zone_data[rpm_bucket].append({"mpg": instant_mpg, "speed": speed})

            # Update displays
            avg_mpg = (sum(self.mpg_samples) / len(self.mpg_samples)) if self.mpg_samples else 0
            self.avg_mpg_box["value_label"].setText("{:.1f}".format(avg_mpg))
            self.total_fuel_box["value_label"].setText("{:.1f} gal".format(self.total_fuel_gal))
            self.total_miles_box["value_label"].setText("{:.1f} mi".format(self.total_miles))

            # Cost per mile
            fuel_price = 4.65  # Brad's current fuel price
            if self.total_miles > 0:
                cost_per_mile = (self.total_fuel_gal * fuel_price) / self.total_miles
                self.cpm_box["value_label"].setText("${:.2f}".format(cost_per_mile))

            # Log to CSV
            self.logger.log_fuel_snapshot(
                live, avg_mpg, self.total_fuel_gal, self.total_miles,
                self._get_best_zone_str())

            # Update zones table
            self._update_zones_table()

    def _update_zones_table(self):
        """Update the RPM/speed zones table."""
        if not self.rpm_zone_data:
            return

        sorted_zones = sorted(self.rpm_zone_data.items())
        self.zones_table.setRowCount(len(sorted_zones))

        best_mpg = 0
        best_zone = ""

        for row, (rpm_bucket, samples) in enumerate(sorted_zones):
            avg_mpg = sum(s["mpg"] for s in samples) / len(samples)
            avg_speed = sum(s["speed"] for s in samples) / len(samples)
            count = len(samples)

            if avg_mpg > best_mpg and count >= 5:
                best_mpg = avg_mpg
                best_zone = "{}-{} RPM".format(rpm_bucket, rpm_bucket + 100)

            # RPM range
            self.zones_table.setItem(row, 0,
                QTableWidgetItem("{}-{}".format(rpm_bucket, rpm_bucket + 100)))

            # Avg speed
            speed_item = QTableWidgetItem("{:.1f}".format(avg_speed))
            self.zones_table.setItem(row, 1, speed_item)

            # Avg MPG
            mpg_item = QTableWidgetItem("{:.2f}".format(avg_mpg))
            if avg_mpg >= 6.0:
                mpg_item.setForeground(QColor("#2ecc71"))
            elif avg_mpg >= 5.0:
                mpg_item.setForeground(QColor("#f39c12"))
            else:
                mpg_item.setForeground(QColor("#e74c3c"))
            self.zones_table.setItem(row, 2, mpg_item)

            # Sample count
            self.zones_table.setItem(row, 3, QTableWidgetItem(str(count)))

            # Rating
            if avg_mpg >= 6.5:
                rating = "EXCELLENT"
                rcolor = "#2ecc71"
            elif avg_mpg >= 5.5:
                rating = "GOOD"
                rcolor = "#3498db"
            elif avg_mpg >= 4.5:
                rating = "AVERAGE"
                rcolor = "#f39c12"
            else:
                rating = "POOR"
                rcolor = "#e74c3c"
            rating_item = QTableWidgetItem(rating)
            rating_item.setForeground(QColor(rcolor))
            self.zones_table.setItem(row, 4, rating_item)

        if best_zone:
            self.sweetspot_label.setText(
                "Best RPM Zone: {} ({:.1f} MPG avg)".format(best_zone, best_mpg))

    def _get_best_zone_str(self):
        best_mpg = 0
        best_zone = ""
        for rpm_bucket, samples in self.rpm_zone_data.items():
            if len(samples) >= 5:
                avg = sum(s["mpg"] for s in samples) / len(samples)
                if avg > best_mpg:
                    best_mpg = avg
                    best_zone = "{}-{}".format(rpm_bucket, rpm_bucket + 100)
        return best_zone

    def _start_session(self):
        import time
        self.session_active = True
        self.last_update_time = time.time()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.logger.start_logging("fuel_session")

    def _stop_session(self):
        self.session_active = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.logger.stop_logging()

    def _reset_session(self):
        self.total_fuel_gal = 0.0
        self.total_miles = 0.0
        self.mpg_samples = []
        self.rpm_zone_data = {}
        self.zones_table.setRowCount(0)
        self.avg_mpg_box["value_label"].setText("0.0")
        self.total_fuel_box["value_label"].setText("0.0 gal")
        self.total_miles_box["value_label"].setText("0.0 mi")
        self.cpm_box["value_label"].setText("$0.00")
        self.sweetspot_label.setText("Best RPM Zone: Collecting data...")
