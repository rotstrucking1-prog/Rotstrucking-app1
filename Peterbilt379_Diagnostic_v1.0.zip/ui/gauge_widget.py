"""
Custom Gauge Widget — Analog + Digital Display
Renders beautiful circular analog gauges with needles, color zones, and digital readouts.
Used for RPM, Boost, Oil Pressure, Coolant Temp, etc.
"""

import math
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QSizePolicy
from PyQt5.QtCore import Qt, QRectF, QPointF, QTimer, pyqtSignal
from PyQt5.QtGui import (QPainter, QPen, QColor, QFont, QConicalGradient,
                          QRadialGradient, QPainterPath, QBrush, QLinearGradient)
from ui.styles import GAUGE_COLORS


class GaugeWidget(QWidget):
    """A single circular gauge with analog needle and digital readout."""

    value_changed = pyqtSignal(float)

    def __init__(self, name="", unit="", min_val=0, max_val=100,
                 warning=None, critical=None, low_danger=False, parent=None):
        super().__init__(parent)
        self.name = name
        self.unit = unit
        self.min_val = min_val
        self.max_val = max_val
        self.warning_threshold = warning
        self.critical_threshold = critical
        self.low_danger = low_danger  # True if LOW values are dangerous (oil press, etc)

        self._value = min_val
        self._target_value = min_val
        self._display_value = min_val
        self._status = "NORMAL"

        # Animation
        self._animation_timer = QTimer(self)
        self._animation_timer.timeout.connect(self._animate)
        self._animation_timer.setInterval(16)  # ~60fps

        # Appearance
        self.setMinimumSize(180, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # Gauge geometry (degrees)
        self.start_angle = 225  # Bottom-left start
        self.span_angle = 270   # Sweep clockwise

    def set_value(self, value):
        """Set the gauge value with smooth animation."""
        self._target_value = max(self.min_val, min(self.max_val, value))
        self._value = self._target_value

        # Determine status
        if self.warning_threshold is not None and self.critical_threshold is not None:
            if self.low_danger:
                if value <= self.critical_threshold:
                    self._status = "CRITICAL"
                elif value <= self.warning_threshold:
                    self._status = "WARNING"
                else:
                    self._status = "NORMAL"
            else:
                if value >= self.critical_threshold:
                    self._status = "CRITICAL"
                elif value >= self.warning_threshold:
                    self._status = "WARNING"
                else:
                    self._status = "NORMAL"
        else:
            self._status = "NORMAL"

        if not self._animation_timer.isActive():
            self._animation_timer.start()

        self.value_changed.emit(self._value)

    def get_value(self):
        return self._value

    def get_status(self):
        return self._status

    def _animate(self):
        """Smooth needle animation toward target value."""
        diff = self._target_value - self._display_value
        if abs(diff) < 0.5:
            self._display_value = self._target_value
            self._animation_timer.stop()
        else:
            self._display_value += diff * 0.15  # Smooth easing
        self.update()

    def paintEvent(self, event):
        """Custom paint for the analog gauge."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        w = self.width()
        h = self.height()
        side = min(w, h - 30)  # Leave room for label
        cx = w / 2
        cy = (h - 30) / 2 + 5

        radius = side / 2 - 10

        # Draw background circle
        self._draw_background(painter, cx, cy, radius)

        # Draw color arc (green/yellow/red zones)
        self._draw_color_arc(painter, cx, cy, radius)

        # Draw tick marks and labels
        self._draw_ticks(painter, cx, cy, radius)

        # Draw needle
        self._draw_needle(painter, cx, cy, radius)

        # Draw center cap
        self._draw_center(painter, cx, cy, radius)

        # Draw digital value
        self._draw_digital(painter, cx, cy, radius)

        # Draw name label at bottom
        self._draw_label(painter, w, h)

        painter.end()

    def _draw_background(self, painter, cx, cy, r):
        """Dark gauge background with subtle gradient."""
        gradient = QRadialGradient(cx, cy, r)
        gradient.setColorAt(0, QColor(GAUGE_COLORS["gauge_bg"]))
        gradient.setColorAt(0.85, QColor(GAUGE_COLORS["gauge_bg"]))
        gradient.setColorAt(1.0, QColor(GAUGE_COLORS["gauge_ring"]))

        painter.setPen(QPen(QColor(GAUGE_COLORS["border"]), 2))
        painter.setBrush(QBrush(gradient))
        painter.drawEllipse(QPointF(cx, cy), r, r)

    def _draw_color_arc(self, painter, cx, cy, r):
        """Draw the colored arc showing normal/warning/critical zones."""
        arc_r = r - 8
        arc_width = 8
        rect = QRectF(cx - arc_r, cy - arc_r, arc_r * 2, arc_r * 2)

        # Calculate zone angles
        total_range = self.max_val - self.min_val
        if total_range == 0:
            return

        # Green zone (normal)
        pen_normal = QPen(QColor(GAUGE_COLORS["normal"]), arc_width, Qt.SolidLine, Qt.RoundCap)
        pen_warning = QPen(QColor(GAUGE_COLORS["warning"]), arc_width, Qt.SolidLine, Qt.RoundCap)
        pen_critical = QPen(QColor(GAUGE_COLORS["critical"]), arc_width, Qt.SolidLine, Qt.RoundCap)

        if self.warning_threshold is not None and self.critical_threshold is not None:
            if self.low_danger:
                # Critical is LOW end, normal is HIGH
                crit_angle = self._value_to_angle(self.critical_threshold)
                warn_angle = self._value_to_angle(self.warning_threshold)
                start_a = self._value_to_angle(self.min_val)
                end_a = self._value_to_angle(self.max_val)

                # Critical zone (low end)
                painter.setPen(pen_critical)
                painter.drawArc(rect, int(start_a * 16), int((crit_angle - start_a) * 16))

                # Warning zone
                painter.setPen(pen_warning)
                painter.drawArc(rect, int(crit_angle * 16), int((warn_angle - crit_angle) * 16))

                # Normal zone (high end)
                painter.setPen(pen_normal)
                painter.drawArc(rect, int(warn_angle * 16), int((end_a - warn_angle) * 16))
            else:
                # Normal is LOW end, critical is HIGH
                warn_angle = self._value_to_angle(self.warning_threshold)
                crit_angle = self._value_to_angle(self.critical_threshold)
                start_a = self._value_to_angle(self.min_val)
                end_a = self._value_to_angle(self.max_val)

                # Normal zone (low end)
                painter.setPen(pen_normal)
                painter.drawArc(rect, int(start_a * 16), int((warn_angle - start_a) * 16))

                # Warning zone
                painter.setPen(pen_warning)
                painter.drawArc(rect, int(warn_angle * 16), int((crit_angle - warn_angle) * 16))

                # Critical zone (high end)
                painter.setPen(pen_critical)
                painter.drawArc(rect, int(crit_angle * 16), int((end_a - crit_angle) * 16))
        else:
            # All normal
            painter.setPen(pen_normal)
            start_a = self._value_to_angle(self.min_val)
            end_a = self._value_to_angle(self.max_val)
            painter.drawArc(rect, int(start_a * 16), int((end_a - start_a) * 16))

    def _draw_ticks(self, painter, cx, cy, r):
        """Draw major and minor tick marks with value labels."""
        total_range = self.max_val - self.min_val
        if total_range == 0:
            return

        num_major = 10
        num_minor = 5

        for i in range(num_major + 1):
            frac = i / num_major
            angle_deg = self.start_angle - frac * self.span_angle
            angle_rad = math.radians(angle_deg)

            # Major tick
            inner_r = r - 20
            outer_r = r - 12
            x1 = cx + inner_r * math.cos(angle_rad)
            y1 = cy - inner_r * math.sin(angle_rad)
            x2 = cx + outer_r * math.cos(angle_rad)
            y2 = cy - outer_r * math.sin(angle_rad)

            painter.setPen(QPen(QColor(GAUGE_COLORS["gauge_tick"]), 2))
            painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))

            # Value label
            value = self.min_val + frac * total_range
            label_r = r - 30
            lx = cx + label_r * math.cos(angle_rad) - 12
            ly = cy - label_r * math.sin(angle_rad) - 6

            painter.setPen(QColor(GAUGE_COLORS["text_secondary"]))
            font = QFont("Segoe UI", 7)
            painter.setFont(font)
            label_text = str(int(value)) if value == int(value) else "{:.1f}".format(value)
            painter.drawText(QRectF(lx, ly, 30, 14), Qt.AlignCenter, label_text)

            # Minor ticks
            if i < num_major:
                for j in range(1, num_minor):
                    mfrac = frac + (j / num_minor) / num_major
                    ma_deg = self.start_angle - mfrac * self.span_angle
                    ma_rad = math.radians(ma_deg)
                    mi_r = r - 16
                    mo_r = r - 12
                    mx1 = cx + mi_r * math.cos(ma_rad)
                    my1 = cy - mi_r * math.sin(ma_rad)
                    mx2 = cx + mo_r * math.cos(ma_rad)
                    my2 = cy - mo_r * math.sin(ma_rad)
                    painter.setPen(QPen(QColor(GAUGE_COLORS["gauge_tick"]), 1))
                    painter.drawLine(QPointF(mx1, my1), QPointF(mx2, my2))

    def _draw_needle(self, painter, cx, cy, r):
        """Draw the gauge needle pointing to current value."""
        total_range = self.max_val - self.min_val
        if total_range == 0:
            return

        frac = (self._display_value - self.min_val) / total_range
        frac = max(0, min(1, frac))
        angle_deg = self.start_angle - frac * self.span_angle
        angle_rad = math.radians(angle_deg)

        needle_len = r - 25
        tip_x = cx + needle_len * math.cos(angle_rad)
        tip_y = cy - needle_len * math.sin(angle_rad)

        # Needle color based on status
        if self._status == "CRITICAL":
            color = QColor(GAUGE_COLORS["critical"])
        elif self._status == "WARNING":
            color = QColor(GAUGE_COLORS["warning"])
        else:
            color = QColor(GAUGE_COLORS["needle"])

        # Draw needle as a triangle
        perp_rad = angle_rad + math.pi / 2
        base_w = 4
        bx1 = cx + base_w * math.cos(perp_rad)
        by1 = cy - base_w * math.sin(perp_rad)
        bx2 = cx - base_w * math.cos(perp_rad)
        by2 = cy + base_w * math.sin(perp_rad)

        path = QPainterPath()
        path.moveTo(tip_x, tip_y)
        path.lineTo(bx1, by1)
        path.lineTo(bx2, by2)
        path.closeSubpath()

        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(color))
        painter.drawPath(path)

        # Needle shadow
        shadow_color = QColor(color)
        shadow_color.setAlpha(60)
        painter.setBrush(QBrush(shadow_color))
        shadow_path = QPainterPath()
        tail_x = cx - 12 * math.cos(angle_rad)
        tail_y = cy + 12 * math.sin(angle_rad)
        shadow_path.moveTo(bx1, by1)
        shadow_path.lineTo(bx2, by2)
        shadow_path.lineTo(tail_x, tail_y)
        shadow_path.closeSubpath()
        painter.drawPath(shadow_path)

    def _draw_center(self, painter, cx, cy, r):
        """Draw the center cap of the gauge."""
        cap_r = 8
        gradient = QRadialGradient(cx, cy, cap_r)
        gradient.setColorAt(0, QColor("#555577"))
        gradient.setColorAt(0.7, QColor("#333355"))
        gradient.setColorAt(1.0, QColor("#1a1a2e"))

        painter.setPen(QPen(QColor("#444466"), 1))
        painter.setBrush(QBrush(gradient))
        painter.drawEllipse(QPointF(cx, cy), cap_r, cap_r)

    def _draw_digital(self, painter, cx, cy, r):
        """Draw the digital value readout below center."""
        # Value
        if self._status == "CRITICAL":
            color = QColor(GAUGE_COLORS["critical"])
        elif self._status == "WARNING":
            color = QColor(GAUGE_COLORS["warning"])
        else:
            color = QColor(GAUGE_COLORS["normal"])

        painter.setPen(color)

        # Format value
        if abs(self._value) >= 1000:
            val_text = "{:,.0f}".format(self._value)
        elif abs(self._value) >= 100:
            val_text = "{:.0f}".format(self._value)
        elif abs(self._value) >= 10:
            val_text = "{:.1f}".format(self._value)
        else:
            val_text = "{:.2f}".format(self._value)

        font = QFont("Consolas", 16, QFont.Bold)
        painter.setFont(font)
        val_rect = QRectF(cx - 50, cy + 15, 100, 25)
        painter.drawText(val_rect, Qt.AlignCenter, val_text)

        # Unit
        painter.setPen(QColor(GAUGE_COLORS["text_secondary"]))
        font = QFont("Segoe UI", 8)
        painter.setFont(font)
        unit_rect = QRectF(cx - 30, cy + 38, 60, 14)
        painter.drawText(unit_rect, Qt.AlignCenter, self.unit)

    def _draw_label(self, painter, w, h):
        """Draw the gauge name label at the bottom."""
        painter.setPen(QColor(GAUGE_COLORS["text_primary"]))
        font = QFont("Segoe UI", 9, QFont.Bold)
        painter.setFont(font)
        label_rect = QRectF(0, h - 22, w, 20)
        painter.drawText(label_rect, Qt.AlignCenter, self.name)

    def _value_to_angle(self, value):
        """Convert a parameter value to a Qt arc angle (in degrees, counter-clockwise from 3 o'clock)."""
        total_range = self.max_val - self.min_val
        if total_range == 0:
            return self.start_angle
        frac = (value - self.min_val) / total_range
        return self.start_angle - frac * self.span_angle


class MiniGaugeWidget(GaugeWidget):
    """Smaller version for compact dashboard view."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setMinimumSize(120, 140)


class DigitalGaugeWidget(QWidget):
    """Digital-only gauge (no needle) for simple values like Engine Hours."""

    def __init__(self, name="", unit="", parent=None):
        super().__init__(parent)
        self.name = name
        self.unit = unit
        self._value = 0
        self._status = "NORMAL"
        self.setMinimumSize(120, 70)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(2)

        self.name_label = QLabel(name)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet("color: #a0a0c0; font-size: 10px; font-weight: bold;")

        self.value_label = QLabel("0")
        self.value_label.setAlignment(Qt.AlignCenter)
        self.value_label.setStyleSheet("color: #2ecc71; font-size: 22px; font-weight: bold; font-family: Consolas;")

        self.unit_label = QLabel(unit)
        self.unit_label.setAlignment(Qt.AlignCenter)
        self.unit_label.setStyleSheet("color: #666688; font-size: 9px;")

        layout.addWidget(self.name_label)
        layout.addWidget(self.value_label)
        layout.addWidget(self.unit_label)

    def set_value(self, value, status="NORMAL"):
        self._value = value
        self._status = status

        if abs(value) >= 1000:
            self.value_label.setText("{:,.0f}".format(value))
        elif abs(value) >= 10:
            self.value_label.setText("{:.1f}".format(value))
        else:
            self.value_label.setText("{:.2f}".format(value))

        colors = {"NORMAL": "#2ecc71", "WARNING": "#f39c12", "CRITICAL": "#e74c3c"}
        self.value_label.setStyleSheet(
            "color: {}; font-size: 22px; font-weight: bold; font-family: Consolas;".format(
                colors.get(status, "#2ecc71")))
