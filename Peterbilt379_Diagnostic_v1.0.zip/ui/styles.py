"""
Dark Theme Styling for Peterbilt 379 Diagnostic Suite
Professional truck diagnostic look — dark background with bright data.
"""

DARK_THEME = """
QMainWindow {
    background-color: #1a1a2e;
    color: #e0e0e0;
}
QWidget {
    background-color: #1a1a2e;
    color: #e0e0e0;
    font-family: 'Segoe UI', Arial, sans-serif;
}
QTabWidget::pane {
    border: 1px solid #333355;
    background: #16213e;
    border-radius: 4px;
}
QTabBar::tab {
    background: #0f3460;
    color: #a0a0c0;
    padding: 10px 20px;
    margin: 2px;
    border-radius: 4px;
    font-size: 13px;
    font-weight: bold;
}
QTabBar::tab:selected {
    background: #e94560;
    color: white;
}
QTabBar::tab:hover {
    background: #533483;
    color: white;
}
QPushButton {
    background-color: #0f3460;
    color: white;
    border: 1px solid #333355;
    padding: 8px 16px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
}
QPushButton:hover {
    background-color: #533483;
}
QPushButton:pressed {
    background-color: #e94560;
}
QPushButton:disabled {
    background-color: #333355;
    color: #666688;
}
QPushButton#danger {
    background-color: #c0392b;
}
QPushButton#danger:hover {
    background-color: #e74c3c;
}
QPushButton#success {
    background-color: #27ae60;
}
QPushButton#success:hover {
    background-color: #2ecc71;
}
QLabel {
    color: #e0e0e0;
}
QLabel#title {
    font-size: 20px;
    font-weight: bold;
    color: #e94560;
}
QLabel#subtitle {
    font-size: 14px;
    color: #a0a0c0;
}
QLabel#value_normal {
    font-size: 28px;
    font-weight: bold;
    color: #2ecc71;
}
QLabel#value_warning {
    font-size: 28px;
    font-weight: bold;
    color: #f39c12;
}
QLabel#value_critical {
    font-size: 28px;
    font-weight: bold;
    color: #e74c3c;
}
QGroupBox {
    border: 1px solid #333355;
    border-radius: 6px;
    margin-top: 10px;
    padding-top: 15px;
    font-weight: bold;
    color: #a0a0c0;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}
QComboBox {
    background-color: #16213e;
    color: white;
    border: 1px solid #333355;
    padding: 6px;
    border-radius: 4px;
}
QComboBox::drop-down {
    border: none;
}
QComboBox QAbstractItemView {
    background-color: #16213e;
    color: white;
    selection-background-color: #533483;
}
QSlider::groove:horizontal {
    border: 1px solid #333355;
    height: 8px;
    background: #16213e;
    border-radius: 4px;
}
QSlider::handle:horizontal {
    background: #e94560;
    border: 1px solid #333355;
    width: 18px;
    margin: -5px 0;
    border-radius: 9px;
}
QSlider::sub-page:horizontal {
    background: #533483;
    border-radius: 4px;
}
QProgressBar {
    border: 1px solid #333355;
    border-radius: 4px;
    text-align: center;
    color: white;
    font-weight: bold;
}
QProgressBar::chunk {
    background-color: #2ecc71;
    border-radius: 4px;
}
QTextEdit, QPlainTextEdit {
    background-color: #0d1b2a;
    color: #00ff88;
    border: 1px solid #333355;
    border-radius: 4px;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 11px;
}
QTableWidget {
    background-color: #16213e;
    color: #e0e0e0;
    gridline-color: #333355;
    border: 1px solid #333355;
}
QTableWidget::item {
    padding: 4px;
}
QTableWidget::item:selected {
    background-color: #533483;
}
QHeaderView::section {
    background-color: #0f3460;
    color: white;
    padding: 6px;
    border: 1px solid #333355;
    font-weight: bold;
}
QScrollBar:vertical {
    background: #1a1a2e;
    width: 12px;
    border-radius: 6px;
}
QScrollBar::handle:vertical {
    background: #333355;
    border-radius: 6px;
    min-height: 20px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QStatusBar {
    background: #0d1b2a;
    color: #a0a0c0;
    border-top: 1px solid #333355;
}
QMenuBar {
    background: #0d1b2a;
    color: #e0e0e0;
}
QMenuBar::item:selected {
    background: #533483;
}
QMenu {
    background: #16213e;
    color: #e0e0e0;
    border: 1px solid #333355;
}
QMenu::item:selected {
    background: #533483;
}
"""

# Color constants for gauges
GAUGE_COLORS = {
    "bg_dark": "#0d1b2a",
    "bg_medium": "#16213e",
    "bg_light": "#1a1a2e",
    "border": "#333355",
    "accent_red": "#e94560",
    "accent_purple": "#533483",
    "accent_blue": "#0f3460",
    "text_primary": "#e0e0e0",
    "text_secondary": "#a0a0c0",
    "normal": "#2ecc71",
    "warning": "#f39c12",
    "critical": "#e74c3c",
    "info": "#3498db",
    "needle": "#ff6b6b",
    "gauge_bg": "#0a0f1e",
    "gauge_ring": "#1e3a5f",
    "gauge_tick": "#4a6fa5",
}
