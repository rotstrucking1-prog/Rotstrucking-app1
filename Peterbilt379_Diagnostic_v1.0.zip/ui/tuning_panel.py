"""
Tuning Panel — 10 Tune Profiles with Activate/Deactivate
Allows modifying ECM parameters with full safety validation and revert.
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
                              QLabel, QPushButton, QSlider, QGroupBox,
                              QTableWidget, QTableWidgetItem, QComboBox,
                              QMessageBox, QInputDialog, QTextEdit, QFrame,
                              QHeaderView, QSizePolicy, QSpinBox, QDoubleSpinBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor, QFont
from data.n14_params import TUNABLE_PARAMS


class TuningPanel(QWidget):
    """Tune profile manager with activate/deactivate and ECM write."""

    tune_activated = pyqtSignal(int, dict)  # profile_id, params
    tune_deactivated = pyqtSignal(int)

    def __init__(self, tune_store, j1708_conn, parent=None):
        super().__init__(parent)
        self.store = tune_store
        self.conn = j1708_conn
        self.param_widgets = {}

        self._setup_ui()
        self._refresh_profiles()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # Header
        header = QHBoxLayout()
        title = QLabel("ENGINE TUNE PROFILES")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #e94560;")
        header.addWidget(title)
        header.addStretch()

        # Safety warning
        warn = QLabel("WARNING: ECM writes affect engine operation. Use at your own risk.")
        warn.setStyleSheet("color: #f39c12; font-size: 10px; font-style: italic;")
        header.addWidget(warn)
        layout.addLayout(header)

        # Profile selector row
        profile_row = QHBoxLayout()

        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(250)
        self.profile_combo.currentIndexChanged.connect(self._on_profile_selected)
        profile_row.addWidget(QLabel("Select Tune:"))
        profile_row.addWidget(self.profile_combo)

        self.activate_btn = QPushButton("ACTIVATE")
        self.activate_btn.setObjectName("success")
        self.activate_btn.clicked.connect(self._activate_profile)
        profile_row.addWidget(self.activate_btn)

        self.deactivate_btn = QPushButton("DEACTIVATE")
        self.deactivate_btn.setObjectName("danger")
        self.deactivate_btn.clicked.connect(self._deactivate_profile)
        profile_row.addWidget(self.deactivate_btn)

        self.revert_btn = QPushButton("REVERT LAST")
        self.revert_btn.clicked.connect(self._revert_last)
        profile_row.addWidget(self.revert_btn)

        profile_row.addStretch()

        self.backup_btn = QPushButton("Backup All")
        self.backup_btn.clicked.connect(self._backup_all)
        profile_row.addWidget(self.backup_btn)

        layout.addLayout(profile_row)

        # Active profile indicator
        self.active_label = QLabel("Active: Tune 1 (Stock / Factory)")
        self.active_label.setStyleSheet(
            "font-size: 14px; font-weight: bold; color: #2ecc71; "
            "padding: 6px; background: #0a2a0a; border-radius: 4px;")
        layout.addWidget(self.active_label)

        # Parameter editor table
        param_group = QGroupBox("Tune Parameters")
        param_layout = QVBoxLayout(param_group)

        self.param_table = QTableWidget()
        self.param_table.setColumnCount(8)
        self.param_table.setHorizontalHeaderLabels([
            "Parameter", "Current Value", "New Value", "Unit",
            "Min Safe", "Max Safe", "Factory Default", "Risk"
        ])
        self.param_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.param_table.setRowCount(len(TUNABLE_PARAMS))

        row = 0
        for key, param in TUNABLE_PARAMS.items():
            # Parameter name
            name_item = QTableWidgetItem(param["name"])
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
            self.param_table.setItem(row, 0, name_item)

            # Current value (from active profile)
            current_item = QTableWidgetItem(str(param["factory_default"]))
            current_item.setFlags(current_item.flags() & ~Qt.ItemIsEditable)
            current_item.setForeground(QColor("#2ecc71"))
            self.param_table.setItem(row, 1, current_item)

            # New value (editable spinner)
            if isinstance(param["factory_default"], float):
                spinner = QDoubleSpinBox()
                spinner.setDecimals(1)
                spinner.setSingleStep(param["step"])
            else:
                spinner = QSpinBox()
                spinner.setSingleStep(int(param["step"]))
            spinner.setMinimum(int(param["min_safe"] * (10 if isinstance(param["factory_default"], float) else 1)))
            spinner.setMaximum(int(param["max_safe"] * (10 if isinstance(param["factory_default"], float) else 1)))
            if isinstance(param["factory_default"], float):
                spinner.setValue(param["factory_default"])
                spinner.setMinimum(param["min_safe"])
                spinner.setMaximum(param["max_safe"])
            else:
                spinner.setMinimum(param["min_safe"])
                spinner.setMaximum(param["max_safe"])
                spinner.setValue(param["factory_default"])
            self.param_table.setCellWidget(row, 2, spinner)
            self.param_widgets[key] = spinner

            # Unit
            unit_item = QTableWidgetItem(param["unit"])
            unit_item.setFlags(unit_item.flags() & ~Qt.ItemIsEditable)
            self.param_table.setItem(row, 3, unit_item)

            # Min safe
            min_item = QTableWidgetItem(str(param["min_safe"]))
            min_item.setFlags(min_item.flags() & ~Qt.ItemIsEditable)
            min_item.setForeground(QColor("#3498db"))
            self.param_table.setItem(row, 4, min_item)

            # Max safe
            max_item = QTableWidgetItem(str(param["max_safe"]))
            max_item.setFlags(max_item.flags() & ~Qt.ItemIsEditable)
            max_item.setForeground(QColor("#e74c3c"))
            self.param_table.setItem(row, 5, max_item)

            # Factory default
            def_item = QTableWidgetItem(str(param["factory_default"]))
            def_item.setFlags(def_item.flags() & ~Qt.ItemIsEditable)
            def_item.setForeground(QColor("#a0a0c0"))
            self.param_table.setItem(row, 6, def_item)

            # Risk level
            risk_item = QTableWidgetItem(param["risk"])
            risk_item.setFlags(risk_item.flags() & ~Qt.ItemIsEditable)
            risk_colors = {"LOW": "#2ecc71", "MEDIUM": "#f39c12", "HIGH": "#e74c3c"}
            risk_item.setForeground(QColor(risk_colors.get(param["risk"], "#a0a0c0")))
            self.param_table.setItem(row, 7, risk_item)

            row += 1

        param_layout.addWidget(self.param_table)

        # Save / Write buttons
        btn_row = QHBoxLayout()

        save_btn = QPushButton("Save to Profile")
        save_btn.setObjectName("success")
        save_btn.clicked.connect(self._save_to_profile)
        btn_row.addWidget(save_btn)

        write_btn = QPushButton("WRITE TO ECM")
        write_btn.setObjectName("danger")
        write_btn.clicked.connect(self._write_to_ecm)
        btn_row.addWidget(write_btn)

        reset_btn = QPushButton("Reset to Factory")
        reset_btn.clicked.connect(self._reset_to_factory)
        btn_row.addWidget(reset_btn)

        compare_btn = QPushButton("Compare Profiles")
        compare_btn.clicked.connect(self._compare_profiles)
        btn_row.addWidget(compare_btn)

        btn_row.addStretch()
        param_layout.addLayout(btn_row)

        layout.addWidget(param_group)

        # Description / notes
        self.desc_label = QTextEdit()
        self.desc_label.setMaximumHeight(80)
        self.desc_label.setReadOnly(True)
        self.desc_label.setPlaceholderText("Profile description and notes will appear here...")
        layout.addWidget(self.desc_label)

    def _refresh_profiles(self):
        """Refresh the profile combo box and active indicator."""
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()

        profiles = self.store.get_all_profiles()
        active_id, active_profile = self.store.get_active_profile()

        for pid in sorted(profiles.keys()):
            p = profiles[pid]
            prefix = "ACTIVE " if p.get("active") else ""
            self.profile_combo.addItem(
                "{}Tune {} - {}".format(prefix, pid, p["name"]), pid)

        if active_id:
            idx = active_id - 1
            if 0 <= idx < self.profile_combo.count():
                self.profile_combo.setCurrentIndex(idx)
            self.active_label.setText(
                "Active: Tune {} ({})".format(active_id, active_profile["name"]))
            self.active_label.setStyleSheet(
                "font-size: 14px; font-weight: bold; color: #2ecc71; "
                "padding: 6px; background: #0a2a0a; border-radius: 4px;")

        self.profile_combo.blockSignals(False)
        self._on_profile_selected(self.profile_combo.currentIndex())

    def _on_profile_selected(self, index):
        """Load selected profile into the parameter editor."""
        pid = self.profile_combo.currentData()
        if pid is None:
            return

        profile = self.store.get_profile(pid)
        if not profile:
            return

        # Update parameter spinners
        params = profile.get("params", {})
        for key, spinner in self.param_widgets.items():
            if key in params:
                spinner.setValue(params[key])

        # Update current value column
        row = 0
        for key in TUNABLE_PARAMS:
            val = params.get(key, TUNABLE_PARAMS[key]["factory_default"])
            self.param_table.item(row, 1).setText(str(val))
            row += 1

        # Description
        desc = profile.get("description", "")
        self.desc_label.setText(desc)

        # Button states
        is_active = profile.get("active", False)
        self.activate_btn.setEnabled(not is_active)
        self.deactivate_btn.setEnabled(is_active and pid != 1)

    def _activate_profile(self):
        """Activate the selected tune profile."""
        pid = self.profile_combo.currentData()
        if pid is None:
            return

        profile = self.store.get_profile(pid)
        reply = QMessageBox.question(
            self, "Activate Tune",
            "Activate Tune {} ({})?\n\nThis will change the active engine tune.\n"
            "All parameter values will be applied.".format(pid, profile["name"]),
            QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            result = self.store.activate_profile(pid)
            if result["status"] == "activated":
                self.tune_activated.emit(pid, result["params"])
                self._refresh_profiles()
                QMessageBox.information(self, "Tune Activated", result["message"])
            else:
                QMessageBox.warning(self, "Error", result.get("message", "Failed"))

    def _deactivate_profile(self):
        """Deactivate the selected tune profile (reverts to Stock)."""
        pid = self.profile_combo.currentData()
        if pid is None or pid == 1:
            return

        reply = QMessageBox.question(
            self, "Deactivate Tune",
            "Deactivate Tune {}?\n\nThis will revert to Stock (Tune 1).".format(pid),
            QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            result = self.store.deactivate_profile(pid)
            if result["status"] == "deactivated":
                self.tune_deactivated.emit(pid)
                self._refresh_profiles()
            else:
                QMessageBox.warning(self, "Error", result.get("message", "Failed"))

    def _save_to_profile(self):
        """Save current spinner values to the selected profile."""
        pid = self.profile_combo.currentData()
        if pid is None:
            return

        params = {}
        for key, spinner in self.param_widgets.items():
            params[key] = spinner.value()

        result = self.store.update_profile(pid, params=params)
        if result["status"] == "updated":
            self._refresh_profiles()
            QMessageBox.information(self, "Saved", "Profile {} updated.".format(pid))
        else:
            QMessageBox.warning(self, "Error", result.get("message", "Save failed"))

    def _write_to_ecm(self):
        """Write active profile parameters to the ECM."""
        if not self.conn.connected:
            QMessageBox.warning(self, "Not Connected",
                                "Connect to the ECM adapter before writing.")
            return

        pid = self.profile_combo.currentData()
        profile = self.store.get_profile(pid)
        if not profile:
            return

        # Double confirmation for ECM write
        reply = QMessageBox.warning(
            self, "WRITE TO ECM",
            "WARNING: You are about to write parameters to the engine ECM.\n\n"
            "Profile: Tune {} ({})\n\n"
            "This will modify engine operation.\n"
            "A backup will be created automatically.\n\n"
            "ARE YOU SURE?".format(pid, profile["name"]),
            QMessageBox.Yes | QMessageBox.No)

        if reply != QMessageBox.Yes:
            return

        # Second confirmation
        reply2 = QMessageBox.critical(
            self, "FINAL CONFIRMATION",
            "LAST CHANCE TO CANCEL!\n\n"
            "Writing to ECM cannot be undone remotely.\n"
            "Incorrect values may damage the engine.\n\n"
            "Type 'WRITE' in the next dialog to confirm.",
            QMessageBox.Ok | QMessageBox.Cancel)

        if reply2 != QMessageBox.Ok:
            return

        text, ok = QInputDialog.getText(self, "Confirm ECM Write",
                                         "Type WRITE to confirm:")
        if not ok or text != "WRITE":
            QMessageBox.information(self, "Cancelled", "ECM write cancelled.")
            return

        # Create backup first
        self.store.create_backup(label="pre_write_tune{}".format(pid))

        # Write each parameter
        params = profile["params"]
        results = []
        for key, value in params.items():
            result = self.conn.write_ecm_parameter(key, value)
            results.append({"param": key, "result": result})

        # Show results
        success = sum(1 for r in results if r["result"]["status"] == "written")
        total = len(results)
        QMessageBox.information(
            self, "ECM Write Complete",
            "Written {}/{} parameters to ECM.\n\n"
            "A backup was saved automatically.".format(success, total))

    def _reset_to_factory(self):
        """Reset selected profile to factory defaults."""
        pid = self.profile_combo.currentData()
        if pid is None:
            return

        reply = QMessageBox.question(
            self, "Reset to Factory",
            "Reset Tune {} to factory defaults?".format(pid),
            QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            self.store.reset_profile(pid)
            self._refresh_profiles()

    def _revert_last(self):
        """Revert the last tune change."""
        result = self.store.revert_last_change()
        if result["status"] == "reverted":
            self._refresh_profiles()
            QMessageBox.information(self, "Reverted", "Last change reverted.")
        else:
            QMessageBox.information(self, "Nothing to Revert", result.get("message", ""))

    def _backup_all(self):
        """Create a full backup of all profiles."""
        result = self.store.create_backup(label="manual")
        QMessageBox.information(self, "Backup Created",
                                "All profiles backed up.\n{}".format(result.get("file", "")))

    def _compare_profiles(self):
        """Compare two profiles side by side."""
        pid_a = self.profile_combo.currentData()
        profiles = self.store.get_all_profiles()

        items = ["Tune {} - {}".format(k, v["name"]) for k, v in sorted(profiles.items())]
        item, ok = QInputDialog.getItem(self, "Compare With", "Select profile to compare:", items, 0, False)
        if not ok:
            return

        pid_b = int(item.split(" ")[1])
        result = self.store.compare_profiles(pid_a, pid_b)

        if not result.get("differences"):
            QMessageBox.information(self, "Identical", "Both profiles have identical parameters.")
            return

        msg = "Tune {} vs Tune {}:\n\n".format(pid_a, pid_b)
        for d in result["differences"]:
            msg += "{}: {} vs {} ({}{})\n".format(
                d["param"], d["tune_a"], d["tune_b"],
                "+" if d["diff"] > 0 else "", d["diff"])

        QMessageBox.information(self, "Comparison", msg)
